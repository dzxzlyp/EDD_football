// ============================================================================
//
// Copyright (c) 2006-2015, Talend SA
//
// Ce code source a été automatiquement généré par_Talend Open Studio for Data Integration
// / Soumis à la Licence Apache, Version 2.0 (la "Licence") ;
// votre utilisation de ce fichier doit respecter les termes de la Licence.
// Vous pouvez obtenir une copie de la Licence sur
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Sauf lorsqu'explicitement prévu par la loi en vigueur ou accepté par écrit, le logiciel
// distribué sous la Licence est distribué "TEL QUEL",
// SANS GARANTIE OU CONDITION D'AUCUNE SORTE, expresse ou implicite.
// Consultez la Licence pour connaître la terminologie spécifique régissant les autorisations et
// les limites prévues par la Licence.

package edd_projet.fusionnage_player_comparison_0_1;

import routines.Numeric;
import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.Relational;
import routines.TalendDate;
import routines.Mathematical;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

@SuppressWarnings("unused")

/**
 * Job: fusionnage_player_comparison Purpose: <br>
 * Description: <br>
 * 
 * @author user@talend.com
 * @version 8.0.1.20211109_1610
 * @status
 */
public class fusionnage_player_comparison implements TalendJob {

	protected static void logIgnoredError(String message, Throwable cause) {
		System.err.println(message);
		if (cause != null) {
			cause.printStackTrace();
		}

	}

	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}

	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	private final static String utf8Charset = "UTF-8";

	// contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String, String> propertyTypes = new java.util.HashMap<>();

		public PropertiesWithType(java.util.Properties properties) {
			super(properties);
		}

		public PropertiesWithType() {
			super();
		}

		public void setContextType(String key, String type) {
			propertyTypes.put(key, type);
		}

		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}

	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

		}

		// if the stored or passed value is "<TALEND_NULL>" string, it mean null
		public String getStringValue(String key) {
			String origin_value = this.getProperty(key);
			if (NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY.equals(origin_value)) {
				return null;
			}
			return origin_value;
		}

	}

	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.

	public ContextProperties getContext() {
		return this.context;
	}

	private final String jobVersion = "0.1";
	private final String jobName = "fusionnage_player_comparison";
	private final String projectName = "EDD_PROJET";
	public Integer errorCode = null;
	private String currentComponent = "";

	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();

	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";

	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(),
					new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	public void setDataSourceReferences(List serviceReferences) throws Exception {

		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		java.util.Map<String, javax.sql.DataSource> dataSources = new java.util.HashMap<String, javax.sql.DataSource>();

		for (java.util.Map.Entry<String, javax.sql.DataSource> entry : BundleUtils
				.getServices(serviceReferences, javax.sql.DataSource.class).entrySet()) {
			dataSources.put(entry.getKey(), entry.getValue());
			talendDataSources.put(entry.getKey(), new routines.system.TalendDataSource(entry.getValue()));
		}

		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		if ("failure".equals(this.getStatus())) {
			errorMessagePS.flush();
			return baos.toString();
		}
		return null;
	}

	private Exception exception;

	public Exception getException() {
		if ("failure".equals(this.getStatus())) {
			return this.exception;
		}
		return null;
	}

	private class TalendException extends Exception {

		private static final long serialVersionUID = 1L;

		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;
		private String currentComponent = null;
		private String virtualComponentName = null;

		public void setVirtualComponentName(String virtualComponentName) {
			this.virtualComponentName = virtualComponentName;
		}

		private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		public Exception getException() {
			return this.e;
		}

		public String getCurrentComponent() {
			return this.currentComponent;
		}

		public String getExceptionCauseMessage(Exception e) {
			Throwable cause = e;
			String message = null;
			int i = 10;
			while (null != cause && 0 < i--) {
				message = cause.getMessage();
				if (null == message) {
					cause = cause.getCause();
				} else {
					break;
				}
			}
			if (null == message) {
				message = e.getClass().getName();
			}
			return message;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				if (virtualComponentName != null && currentComponent.indexOf(virtualComponentName + "_") == 0) {
					globalMap.put(virtualComponentName + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				}
				globalMap.put(currentComponent + "_ERROR_MESSAGE", getExceptionCauseMessage(e));
				System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
					fusionnage_player_comparison.this.exception = e;
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(fusionnage_player_comparison.this,
									new Object[] { e, currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
					}
				} catch (Exception e) {
					this.e.printStackTrace();
				}
			}
		}
	}

	public void tFileInputDelimited_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileOutputExcel_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_2_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_3_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileOutputDelimited_1_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileOutputDelimited_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAdvancedHash_all_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tAdvancedHash_team_error(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		end_Hash.put(errorComponent, System.currentTimeMillis());

		status = "failure";

		tFileInputDelimited_3_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_3_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public void tFileOutputDelimited_1_onSubJobError(Exception exception, String errorComponent,
			final java.util.Map<String, Object> globalMap) throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread.currentThread().getId() + "", "FATAL", "",
				exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception), "");

	}

	public static class allStruct implements routines.system.IPersistableComparableLookupRow<allStruct> {
		final static byte[] commonByteArrayLock_EDD_PROJET_fusionnage_player_comparison = new byte[0];
		static byte[] commonByteArray_EDD_PROJET_fusionnage_player_comparison = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int player_api_id;

		public int getPlayer_api_id() {
			return this.player_api_id;
		}

		public String player_name;

		public String getPlayer_name() {
			return this.player_name;
		}

		public String saison;

		public String getSaison() {
			return this.saison;
		}

		public Float overall_rating;

		public Float getOverall_rating() {
			return this.overall_rating;
		}

		public Float potential;

		public Float getPotential() {
			return this.potential;
		}

		public Float finishing;

		public Float getFinishing() {
			return this.finishing;
		}

		public Float heading_accuracy;

		public Float getHeading_accuracy() {
			return this.heading_accuracy;
		}

		public Float short_passing;

		public Float getShort_passing() {
			return this.short_passing;
		}

		public Float dribbling;

		public Float getDribbling() {
			return this.dribbling;
		}

		public Float sprint_speed;

		public Float getSprint_speed() {
			return this.sprint_speed;
		}

		public Float balance;

		public Float getBalance() {
			return this.balance;
		}

		public Float shot_power;

		public Float getShot_power() {
			return this.shot_power;
		}

		public Float jumping;

		public Float getJumping() {
			return this.jumping;
		}

		public Float stamina;

		public Float getStamina() {
			return this.stamina;
		}

		public Float strength;

		public Float getStrength() {
			return this.strength;
		}

		public Float positioning;

		public Float getPositioning() {
			return this.positioning;
		}

		public Float penalties;

		public Float getPenalties() {
			return this.penalties;
		}

		public Float sliding_tackle;

		public Float getSliding_tackle() {
			return this.sliding_tackle;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.player_api_id;

				result = prime * result + ((this.saison == null) ? 0 : this.saison.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final allStruct other = (allStruct) obj;

			if (this.player_api_id != other.player_api_id)
				return false;

			if (this.saison == null) {
				if (other.saison != null)
					return false;

			} else if (!this.saison.equals(other.saison))

				return false;

			return true;
		}

		public void copyDataTo(allStruct other) {

			other.player_api_id = this.player_api_id;
			other.player_name = this.player_name;
			other.saison = this.saison;
			other.overall_rating = this.overall_rating;
			other.potential = this.potential;
			other.finishing = this.finishing;
			other.heading_accuracy = this.heading_accuracy;
			other.short_passing = this.short_passing;
			other.dribbling = this.dribbling;
			other.sprint_speed = this.sprint_speed;
			other.balance = this.balance;
			other.shot_power = this.shot_power;
			other.jumping = this.jumping;
			other.stamina = this.stamina;
			other.strength = this.strength;
			other.positioning = this.positioning;
			other.penalties = this.penalties;
			other.sliding_tackle = this.sliding_tackle;

		}

		public void copyKeysDataTo(allStruct other) {

			other.player_api_id = this.player_api_id;
			other.saison = this.saison;

		}

		private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				byte[] byteArray = new byte[length];
				dis.read(byteArray);
				strReturn = new String(byteArray, utf8Charset);
			}
			return strReturn;
		}

		private String readString(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller)
				throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				byte[] byteArray = new byte[length];
				unmarshaller.read(byteArray);
				strReturn = new String(byteArray, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller)
				throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_EDD_PROJET_fusionnage_player_comparison.length) {
					if (length < 1024 && commonByteArray_EDD_PROJET_fusionnage_player_comparison.length == 0) {
						commonByteArray_EDD_PROJET_fusionnage_player_comparison = new byte[1024];
					} else {
						commonByteArray_EDD_PROJET_fusionnage_player_comparison = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_EDD_PROJET_fusionnage_player_comparison, 0, length);
				strReturn = new String(commonByteArray_EDD_PROJET_fusionnage_player_comparison, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_EDD_PROJET_fusionnage_player_comparison.length) {
					if (length < 1024 && commonByteArray_EDD_PROJET_fusionnage_player_comparison.length == 0) {
						commonByteArray_EDD_PROJET_fusionnage_player_comparison = new byte[1024];
					} else {
						commonByteArray_EDD_PROJET_fusionnage_player_comparison = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_EDD_PROJET_fusionnage_player_comparison, 0, length);
				strReturn = new String(commonByteArray_EDD_PROJET_fusionnage_player_comparison, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readKeysData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_EDD_PROJET_fusionnage_player_comparison) {

				try {

					int length = 0;

					this.player_api_id = dis.readInt();

					this.saison = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_EDD_PROJET_fusionnage_player_comparison) {

				try {

					int length = 0;

					this.player_api_id = dis.readInt();

					this.saison = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeKeysData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.player_api_id);

				// String

				writeString(this.saison, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.player_api_id);

				// String

				writeString(this.saison, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		/**
		 * Fill Values data by reading ObjectInputStream.
		 */
		public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
			try {

				int length = 0;

				this.player_name = readString(dis, ois);

				length = dis.readByte();
				if (length == -1) {
					this.overall_rating = null;
				} else {
					this.overall_rating = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.potential = null;
				} else {
					this.potential = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.finishing = null;
				} else {
					this.finishing = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.heading_accuracy = null;
				} else {
					this.heading_accuracy = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.short_passing = null;
				} else {
					this.short_passing = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.dribbling = null;
				} else {
					this.dribbling = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.sprint_speed = null;
				} else {
					this.sprint_speed = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.balance = null;
				} else {
					this.balance = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.shot_power = null;
				} else {
					this.shot_power = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.jumping = null;
				} else {
					this.jumping = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.stamina = null;
				} else {
					this.stamina = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.strength = null;
				} else {
					this.strength = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.positioning = null;
				} else {
					this.positioning = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.penalties = null;
				} else {
					this.penalties = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.sliding_tackle = null;
				} else {
					this.sliding_tackle = dis.readFloat();
				}

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
			try {
				int length = 0;

				this.player_name = readString(dis, objectIn);

				length = objectIn.readByte();
				if (length == -1) {
					this.overall_rating = null;
				} else {
					this.overall_rating = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.potential = null;
				} else {
					this.potential = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.finishing = null;
				} else {
					this.finishing = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.heading_accuracy = null;
				} else {
					this.heading_accuracy = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.short_passing = null;
				} else {
					this.short_passing = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.dribbling = null;
				} else {
					this.dribbling = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.sprint_speed = null;
				} else {
					this.sprint_speed = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.balance = null;
				} else {
					this.balance = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.shot_power = null;
				} else {
					this.shot_power = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.jumping = null;
				} else {
					this.jumping = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.stamina = null;
				} else {
					this.stamina = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.strength = null;
				} else {
					this.strength = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.positioning = null;
				} else {
					this.positioning = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.penalties = null;
				} else {
					this.penalties = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.sliding_tackle = null;
				} else {
					this.sliding_tackle = objectIn.readFloat();
				}

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		/**
		 * Return a byte array which represents Values data.
		 */
		public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
			try {

				writeString(this.player_name, dos, oos);

				if (this.overall_rating == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.overall_rating);
				}

				if (this.potential == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.potential);
				}

				if (this.finishing == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.finishing);
				}

				if (this.heading_accuracy == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.heading_accuracy);
				}

				if (this.short_passing == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.short_passing);
				}

				if (this.dribbling == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.dribbling);
				}

				if (this.sprint_speed == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.sprint_speed);
				}

				if (this.balance == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.balance);
				}

				if (this.shot_power == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.shot_power);
				}

				if (this.jumping == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.jumping);
				}

				if (this.stamina == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.stamina);
				}

				if (this.strength == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.strength);
				}

				if (this.positioning == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.positioning);
				}

				if (this.penalties == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.penalties);
				}

				if (this.sliding_tackle == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.sliding_tackle);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut) {
			try {

				writeString(this.player_name, dos, objectOut);

				if (this.overall_rating == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.overall_rating);
				}

				if (this.potential == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.potential);
				}

				if (this.finishing == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.finishing);
				}

				if (this.heading_accuracy == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.heading_accuracy);
				}

				if (this.short_passing == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.short_passing);
				}

				if (this.dribbling == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.dribbling);
				}

				if (this.sprint_speed == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.sprint_speed);
				}

				if (this.balance == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.balance);
				}

				if (this.shot_power == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.shot_power);
				}

				if (this.jumping == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.jumping);
				}

				if (this.stamina == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.stamina);
				}

				if (this.strength == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.strength);
				}

				if (this.positioning == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.positioning);
				}

				if (this.penalties == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.penalties);
				}

				if (this.sliding_tackle == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.sliding_tackle);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		public boolean supportMarshaller() {
			return true;
		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("player_api_id=" + String.valueOf(player_api_id));
			sb.append(",player_name=" + player_name);
			sb.append(",saison=" + saison);
			sb.append(",overall_rating=" + String.valueOf(overall_rating));
			sb.append(",potential=" + String.valueOf(potential));
			sb.append(",finishing=" + String.valueOf(finishing));
			sb.append(",heading_accuracy=" + String.valueOf(heading_accuracy));
			sb.append(",short_passing=" + String.valueOf(short_passing));
			sb.append(",dribbling=" + String.valueOf(dribbling));
			sb.append(",sprint_speed=" + String.valueOf(sprint_speed));
			sb.append(",balance=" + String.valueOf(balance));
			sb.append(",shot_power=" + String.valueOf(shot_power));
			sb.append(",jumping=" + String.valueOf(jumping));
			sb.append(",stamina=" + String.valueOf(stamina));
			sb.append(",strength=" + String.valueOf(strength));
			sb.append(",positioning=" + String.valueOf(positioning));
			sb.append(",penalties=" + String.valueOf(penalties));
			sb.append(",sliding_tackle=" + String.valueOf(sliding_tackle));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(allStruct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.player_api_id, other.player_api_id);
			if (returnValue != 0) {
				return returnValue;
			}

			returnValue = checkNullsAndCompare(this.saison, other.saison);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				allStruct all = new allStruct();

				/**
				 * [tAdvancedHash_all begin ] start
				 */

				ok_Hash.put("tAdvancedHash_all", false);
				start_Hash.put("tAdvancedHash_all", System.currentTimeMillis());

				currentComponent = "tAdvancedHash_all";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "all");
				}

				int tos_count_tAdvancedHash_all = 0;

				// connection name:all
				// source node:tFileInputDelimited_1 - inputs:(after_tFileInputDelimited_3)
				// outputs:(all,all) | target node:tAdvancedHash_all - inputs:(all) outputs:()
				// linked node: tMap_1 - inputs:(all,team,player) outputs:(out1)

				org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_all = org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<allStruct> tHash_Lookup_all = org.talend.designer.components.lookup.memory.AdvancedMemoryLookup
						.<allStruct>getLookup(matchingModeEnum_all);

				globalMap.put("tHash_Lookup_all", tHash_Lookup_all);

				/**
				 * [tAdvancedHash_all begin ] stop
				 */

				/**
				 * [tFileInputDelimited_1 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_1", false);
				start_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());

				currentComponent = "tFileInputDelimited_1";

				int tos_count_tFileInputDelimited_1 = 0;

				final routines.system.RowState rowstate_tFileInputDelimited_1 = new routines.system.RowState();

				int nb_line_tFileInputDelimited_1 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_1 = null;
				int limit_tFileInputDelimited_1 = -1;
				try {

					Object filename_tFileInputDelimited_1 = "C:/Users/Thinkpad/Desktop/avg_all_by_player.csv";
					if (filename_tFileInputDelimited_1 instanceof java.io.InputStream) {

						int footer_value_tFileInputDelimited_1 = 0, random_value_tFileInputDelimited_1 = -1;
						if (footer_value_tFileInputDelimited_1 > 0 || random_value_tFileInputDelimited_1 > 0) {
							throw new java.lang.Exception(
									"When the input source is a stream,footer and random shouldn't be bigger than 0.");
						}

					}
					try {
						fid_tFileInputDelimited_1 = new org.talend.fileprocess.FileInputDelimited(
								"C:/Users/Thinkpad/Desktop/avg_all_by_player.csv", "US-ASCII", ";", "\n", false, 1, 0,
								limit_tFileInputDelimited_1, -1, false);
					} catch (java.lang.Exception e) {
						globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE", e.getMessage());

						System.err.println(e.getMessage());

					}

					while (fid_tFileInputDelimited_1 != null && fid_tFileInputDelimited_1.nextRecord()) {
						rowstate_tFileInputDelimited_1.reset();

						all = null;

						all = null;

						boolean whetherReject_tFileInputDelimited_1 = false;
						all = new allStruct();
						try {

							int columnIndexWithD_tFileInputDelimited_1 = 0;

							String temp = "";

							columnIndexWithD_tFileInputDelimited_1 = 0;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									all.player_api_id = ParserUtils.parseTo_int(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"player_api_id", "all", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								rowstate_tFileInputDelimited_1.setException(new RuntimeException(
										"Value is empty for column : 'player_api_id' in 'all' connection, value is invalid or this column should be nullable or have a default value."));

							}

							columnIndexWithD_tFileInputDelimited_1 = 1;

							all.player_name = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 2;

							all.saison = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);

							columnIndexWithD_tFileInputDelimited_1 = 3;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									all.overall_rating = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"overall_rating", "all", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								all.overall_rating = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 4;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									all.potential = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"potential", "all", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								all.potential = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 5;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									all.finishing = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"finishing", "all", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								all.finishing = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 6;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									all.heading_accuracy = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"heading_accuracy", "all", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								all.heading_accuracy = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 7;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									all.short_passing = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"short_passing", "all", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								all.short_passing = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 8;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									all.dribbling = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"dribbling", "all", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								all.dribbling = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 9;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									all.sprint_speed = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"sprint_speed", "all", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								all.sprint_speed = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 10;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									all.balance = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"balance", "all", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								all.balance = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 11;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									all.shot_power = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"shot_power", "all", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								all.shot_power = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 12;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									all.jumping = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"jumping", "all", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								all.jumping = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 13;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									all.stamina = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"stamina", "all", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								all.stamina = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 14;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									all.strength = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"strength", "all", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								all.strength = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 15;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									all.positioning = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"positioning", "all", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								all.positioning = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 16;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									all.penalties = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"penalties", "all", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								all.penalties = null;

							}

							columnIndexWithD_tFileInputDelimited_1 = 17;

							temp = fid_tFileInputDelimited_1.get(columnIndexWithD_tFileInputDelimited_1);
							if (temp.length() > 0) {

								try {

									all.sliding_tackle = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_1) {
									globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE",
											ex_tFileInputDelimited_1.getMessage());
									rowstate_tFileInputDelimited_1.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"sliding_tackle", "all", temp, ex_tFileInputDelimited_1),
											ex_tFileInputDelimited_1));
								}

							} else {

								all.sliding_tackle = null;

							}

							if (rowstate_tFileInputDelimited_1.getException() != null) {
								throw rowstate_tFileInputDelimited_1.getException();
							}

						} catch (java.lang.Exception e) {
							globalMap.put("tFileInputDelimited_1_ERROR_MESSAGE", e.getMessage());
							whetherReject_tFileInputDelimited_1 = true;

							System.err.println(e.getMessage());
							all = null;

						}

						/**
						 * [tFileInputDelimited_1 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_1 main ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						tos_count_tFileInputDelimited_1++;

						/**
						 * [tFileInputDelimited_1 main ] stop
						 */

						/**
						 * [tFileInputDelimited_1 process_data_begin ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						/**
						 * [tFileInputDelimited_1 process_data_begin ] stop
						 */
// Start of branch "all"
						if (all != null) {

							/**
							 * [tAdvancedHash_all main ] start
							 */

							currentComponent = "tAdvancedHash_all";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "all"

								);
							}

							allStruct all_HashRow = new allStruct();

							all_HashRow.player_api_id = all.player_api_id;

							all_HashRow.player_name = all.player_name;

							all_HashRow.saison = all.saison;

							all_HashRow.overall_rating = all.overall_rating;

							all_HashRow.potential = all.potential;

							all_HashRow.finishing = all.finishing;

							all_HashRow.heading_accuracy = all.heading_accuracy;

							all_HashRow.short_passing = all.short_passing;

							all_HashRow.dribbling = all.dribbling;

							all_HashRow.sprint_speed = all.sprint_speed;

							all_HashRow.balance = all.balance;

							all_HashRow.shot_power = all.shot_power;

							all_HashRow.jumping = all.jumping;

							all_HashRow.stamina = all.stamina;

							all_HashRow.strength = all.strength;

							all_HashRow.positioning = all.positioning;

							all_HashRow.penalties = all.penalties;

							all_HashRow.sliding_tackle = all.sliding_tackle;

							tHash_Lookup_all.put(all_HashRow);

							tos_count_tAdvancedHash_all++;

							/**
							 * [tAdvancedHash_all main ] stop
							 */

							/**
							 * [tAdvancedHash_all process_data_begin ] start
							 */

							currentComponent = "tAdvancedHash_all";

							/**
							 * [tAdvancedHash_all process_data_begin ] stop
							 */

							/**
							 * [tAdvancedHash_all process_data_end ] start
							 */

							currentComponent = "tAdvancedHash_all";

							/**
							 * [tAdvancedHash_all process_data_end ] stop
							 */

						} // End of branch "all"

						/**
						 * [tFileInputDelimited_1 process_data_end ] start
						 */

						currentComponent = "tFileInputDelimited_1";

						/**
						 * [tFileInputDelimited_1 process_data_end ] stop
						 */

						/**
						 * [tFileInputDelimited_1 end ] start
						 */

						currentComponent = "tFileInputDelimited_1";

					}
				} finally {
					if (!((Object) ("C:/Users/Thinkpad/Desktop/avg_all_by_player.csv") instanceof java.io.InputStream)) {
						if (fid_tFileInputDelimited_1 != null) {
							fid_tFileInputDelimited_1.close();
						}
					}
					if (fid_tFileInputDelimited_1 != null) {
						globalMap.put("tFileInputDelimited_1_NB_LINE", fid_tFileInputDelimited_1.getRowNumber());

					}
				}

				ok_Hash.put("tFileInputDelimited_1", true);
				end_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());

				/**
				 * [tFileInputDelimited_1 end ] stop
				 */

				/**
				 * [tAdvancedHash_all end ] start
				 */

				currentComponent = "tAdvancedHash_all";

				tHash_Lookup_all.endPut();

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "all");
				}

				ok_Hash.put("tAdvancedHash_all", true);
				end_Hash.put("tAdvancedHash_all", System.currentTimeMillis());

				/**
				 * [tAdvancedHash_all end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tFileInputDelimited_1 finally ] start
				 */

				currentComponent = "tFileInputDelimited_1";

				/**
				 * [tFileInputDelimited_1 finally ] stop
				 */

				/**
				 * [tAdvancedHash_all finally ] start
				 */

				currentComponent = "tAdvancedHash_all";

				/**
				 * [tAdvancedHash_all finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 1);
	}

	public static class teamStruct implements routines.system.IPersistableComparableLookupRow<teamStruct> {
		final static byte[] commonByteArrayLock_EDD_PROJET_fusionnage_player_comparison = new byte[0];
		static byte[] commonByteArray_EDD_PROJET_fusionnage_player_comparison = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public Integer player_api_id;

		public Integer getPlayer_api_id() {
			return this.player_api_id;
		}

		public String player_name;

		public String getPlayer_name() {
			return this.player_name;
		}

		public Integer team_api_id;

		public Integer getTeam_api_id() {
			return this.team_api_id;
		}

		public String saison;

		public String getSaison() {
			return this.saison;
		}

		public Float overall_rating;

		public Float getOverall_rating() {
			return this.overall_rating;
		}

		public Float potential;

		public Float getPotential() {
			return this.potential;
		}

		public Float finishing;

		public Float getFinishing() {
			return this.finishing;
		}

		public Float heading_accuracy;

		public Float getHeading_accuracy() {
			return this.heading_accuracy;
		}

		public Float short_passing;

		public Float getShort_passing() {
			return this.short_passing;
		}

		public Float dribbling;

		public Float getDribbling() {
			return this.dribbling;
		}

		public Float sprint_speed;

		public Float getSprint_speed() {
			return this.sprint_speed;
		}

		public Float balance;

		public Float getBalance() {
			return this.balance;
		}

		public Float shot_power;

		public Float getShot_power() {
			return this.shot_power;
		}

		public Float jumping;

		public Float getJumping() {
			return this.jumping;
		}

		public Float stamina;

		public Float getStamina() {
			return this.stamina;
		}

		public Float strength;

		public Float getStrength() {
			return this.strength;
		}

		public Float positioning;

		public Float getPositioning() {
			return this.positioning;
		}

		public Float penalties;

		public Float getPenalties() {
			return this.penalties;
		}

		public Float sliding_tackle;

		public Float getSliding_tackle() {
			return this.sliding_tackle;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + ((this.player_api_id == null) ? 0 : this.player_api_id.hashCode());

				result = prime * result + ((this.saison == null) ? 0 : this.saison.hashCode());

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final teamStruct other = (teamStruct) obj;

			if (this.player_api_id == null) {
				if (other.player_api_id != null)
					return false;

			} else if (!this.player_api_id.equals(other.player_api_id))

				return false;

			if (this.saison == null) {
				if (other.saison != null)
					return false;

			} else if (!this.saison.equals(other.saison))

				return false;

			return true;
		}

		public void copyDataTo(teamStruct other) {

			other.player_api_id = this.player_api_id;
			other.player_name = this.player_name;
			other.team_api_id = this.team_api_id;
			other.saison = this.saison;
			other.overall_rating = this.overall_rating;
			other.potential = this.potential;
			other.finishing = this.finishing;
			other.heading_accuracy = this.heading_accuracy;
			other.short_passing = this.short_passing;
			other.dribbling = this.dribbling;
			other.sprint_speed = this.sprint_speed;
			other.balance = this.balance;
			other.shot_power = this.shot_power;
			other.jumping = this.jumping;
			other.stamina = this.stamina;
			other.strength = this.strength;
			other.positioning = this.positioning;
			other.penalties = this.penalties;
			other.sliding_tackle = this.sliding_tackle;

		}

		public void copyKeysDataTo(teamStruct other) {

			other.player_api_id = this.player_api_id;
			other.saison = this.saison;

		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(DataInputStream dis, ObjectInputStream ois) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				byte[] byteArray = new byte[length];
				dis.read(byteArray);
				strReturn = new String(byteArray, utf8Charset);
			}
			return strReturn;
		}

		private String readString(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller)
				throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				byte[] byteArray = new byte[length];
				unmarshaller.read(byteArray);
				strReturn = new String(byteArray, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller)
				throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private void writeString(String str, DataOutputStream dos, ObjectOutputStream oos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private Integer readInteger(DataInputStream dis, ObjectInputStream ois) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(DataInputStream dis, org.jboss.marshalling.Unmarshaller unmarshaller)
				throws IOException {
			Integer intReturn;
			int length = 0;
			length = unmarshaller.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = unmarshaller.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, DataOutputStream dos, ObjectOutputStream oos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, DataOutputStream dos, org.jboss.marshalling.Marshaller marshaller)
				throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_EDD_PROJET_fusionnage_player_comparison.length) {
					if (length < 1024 && commonByteArray_EDD_PROJET_fusionnage_player_comparison.length == 0) {
						commonByteArray_EDD_PROJET_fusionnage_player_comparison = new byte[1024];
					} else {
						commonByteArray_EDD_PROJET_fusionnage_player_comparison = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_EDD_PROJET_fusionnage_player_comparison, 0, length);
				strReturn = new String(commonByteArray_EDD_PROJET_fusionnage_player_comparison, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_EDD_PROJET_fusionnage_player_comparison.length) {
					if (length < 1024 && commonByteArray_EDD_PROJET_fusionnage_player_comparison.length == 0) {
						commonByteArray_EDD_PROJET_fusionnage_player_comparison = new byte[1024];
					} else {
						commonByteArray_EDD_PROJET_fusionnage_player_comparison = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_EDD_PROJET_fusionnage_player_comparison, 0, length);
				strReturn = new String(commonByteArray_EDD_PROJET_fusionnage_player_comparison, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readKeysData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_EDD_PROJET_fusionnage_player_comparison) {

				try {

					int length = 0;

					this.player_api_id = readInteger(dis);

					this.saison = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readKeysData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_EDD_PROJET_fusionnage_player_comparison) {

				try {

					int length = 0;

					this.player_api_id = readInteger(dis);

					this.saison = readString(dis);

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeKeysData(ObjectOutputStream dos) {
			try {

				// Integer

				writeInteger(this.player_api_id, dos);

				// String

				writeString(this.saison, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeKeysData(org.jboss.marshalling.Marshaller dos) {
			try {

				// Integer

				writeInteger(this.player_api_id, dos);

				// String

				writeString(this.saison, dos);

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		/**
		 * Fill Values data by reading ObjectInputStream.
		 */
		public void readValuesData(DataInputStream dis, ObjectInputStream ois) {
			try {

				int length = 0;

				this.player_name = readString(dis, ois);

				this.team_api_id = readInteger(dis, ois);

				length = dis.readByte();
				if (length == -1) {
					this.overall_rating = null;
				} else {
					this.overall_rating = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.potential = null;
				} else {
					this.potential = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.finishing = null;
				} else {
					this.finishing = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.heading_accuracy = null;
				} else {
					this.heading_accuracy = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.short_passing = null;
				} else {
					this.short_passing = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.dribbling = null;
				} else {
					this.dribbling = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.sprint_speed = null;
				} else {
					this.sprint_speed = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.balance = null;
				} else {
					this.balance = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.shot_power = null;
				} else {
					this.shot_power = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.jumping = null;
				} else {
					this.jumping = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.stamina = null;
				} else {
					this.stamina = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.strength = null;
				} else {
					this.strength = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.positioning = null;
				} else {
					this.positioning = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.penalties = null;
				} else {
					this.penalties = dis.readFloat();
				}

				length = dis.readByte();
				if (length == -1) {
					this.sliding_tackle = null;
				} else {
					this.sliding_tackle = dis.readFloat();
				}

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		public void readValuesData(DataInputStream dis, org.jboss.marshalling.Unmarshaller objectIn) {
			try {
				int length = 0;

				this.player_name = readString(dis, objectIn);

				this.team_api_id = readInteger(dis, objectIn);

				length = objectIn.readByte();
				if (length == -1) {
					this.overall_rating = null;
				} else {
					this.overall_rating = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.potential = null;
				} else {
					this.potential = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.finishing = null;
				} else {
					this.finishing = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.heading_accuracy = null;
				} else {
					this.heading_accuracy = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.short_passing = null;
				} else {
					this.short_passing = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.dribbling = null;
				} else {
					this.dribbling = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.sprint_speed = null;
				} else {
					this.sprint_speed = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.balance = null;
				} else {
					this.balance = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.shot_power = null;
				} else {
					this.shot_power = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.jumping = null;
				} else {
					this.jumping = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.stamina = null;
				} else {
					this.stamina = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.strength = null;
				} else {
					this.strength = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.positioning = null;
				} else {
					this.positioning = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.penalties = null;
				} else {
					this.penalties = objectIn.readFloat();
				}

				length = objectIn.readByte();
				if (length == -1) {
					this.sliding_tackle = null;
				} else {
					this.sliding_tackle = objectIn.readFloat();
				}

			} catch (IOException e) {
				throw new RuntimeException(e);

			}

		}

		/**
		 * Return a byte array which represents Values data.
		 */
		public void writeValuesData(DataOutputStream dos, ObjectOutputStream oos) {
			try {

				writeString(this.player_name, dos, oos);

				writeInteger(this.team_api_id, dos, oos);

				if (this.overall_rating == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.overall_rating);
				}

				if (this.potential == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.potential);
				}

				if (this.finishing == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.finishing);
				}

				if (this.heading_accuracy == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.heading_accuracy);
				}

				if (this.short_passing == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.short_passing);
				}

				if (this.dribbling == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.dribbling);
				}

				if (this.sprint_speed == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.sprint_speed);
				}

				if (this.balance == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.balance);
				}

				if (this.shot_power == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.shot_power);
				}

				if (this.jumping == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.jumping);
				}

				if (this.stamina == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.stamina);
				}

				if (this.strength == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.strength);
				}

				if (this.positioning == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.positioning);
				}

				if (this.penalties == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.penalties);
				}

				if (this.sliding_tackle == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.sliding_tackle);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeValuesData(DataOutputStream dos, org.jboss.marshalling.Marshaller objectOut) {
			try {

				writeString(this.player_name, dos, objectOut);

				writeInteger(this.team_api_id, dos, objectOut);

				if (this.overall_rating == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.overall_rating);
				}

				if (this.potential == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.potential);
				}

				if (this.finishing == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.finishing);
				}

				if (this.heading_accuracy == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.heading_accuracy);
				}

				if (this.short_passing == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.short_passing);
				}

				if (this.dribbling == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.dribbling);
				}

				if (this.sprint_speed == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.sprint_speed);
				}

				if (this.balance == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.balance);
				}

				if (this.shot_power == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.shot_power);
				}

				if (this.jumping == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.jumping);
				}

				if (this.stamina == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.stamina);
				}

				if (this.strength == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.strength);
				}

				if (this.positioning == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.positioning);
				}

				if (this.penalties == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.penalties);
				}

				if (this.sliding_tackle == null) {
					objectOut.writeByte(-1);
				} else {
					objectOut.writeByte(0);
					objectOut.writeFloat(this.sliding_tackle);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}
		}

		public boolean supportMarshaller() {
			return true;
		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("player_api_id=" + String.valueOf(player_api_id));
			sb.append(",player_name=" + player_name);
			sb.append(",team_api_id=" + String.valueOf(team_api_id));
			sb.append(",saison=" + saison);
			sb.append(",overall_rating=" + String.valueOf(overall_rating));
			sb.append(",potential=" + String.valueOf(potential));
			sb.append(",finishing=" + String.valueOf(finishing));
			sb.append(",heading_accuracy=" + String.valueOf(heading_accuracy));
			sb.append(",short_passing=" + String.valueOf(short_passing));
			sb.append(",dribbling=" + String.valueOf(dribbling));
			sb.append(",sprint_speed=" + String.valueOf(sprint_speed));
			sb.append(",balance=" + String.valueOf(balance));
			sb.append(",shot_power=" + String.valueOf(shot_power));
			sb.append(",jumping=" + String.valueOf(jumping));
			sb.append(",stamina=" + String.valueOf(stamina));
			sb.append(",strength=" + String.valueOf(strength));
			sb.append(",positioning=" + String.valueOf(positioning));
			sb.append(",penalties=" + String.valueOf(penalties));
			sb.append(",sliding_tackle=" + String.valueOf(sliding_tackle));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(teamStruct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.player_api_id, other.player_api_id);
			if (returnValue != 0) {
				return returnValue;
			}

			returnValue = checkNullsAndCompare(this.saison, other.saison);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				teamStruct team = new teamStruct();

				/**
				 * [tAdvancedHash_team begin ] start
				 */

				ok_Hash.put("tAdvancedHash_team", false);
				start_Hash.put("tAdvancedHash_team", System.currentTimeMillis());

				currentComponent = "tAdvancedHash_team";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "team");
				}

				int tos_count_tAdvancedHash_team = 0;

				// connection name:team
				// source node:tFileInputDelimited_2 - inputs:(after_tFileInputDelimited_3)
				// outputs:(team,team) | target node:tAdvancedHash_team - inputs:(team)
				// outputs:()
				// linked node: tMap_1 - inputs:(all,team,player) outputs:(out1)

				org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE matchingModeEnum_team = org.talend.designer.components.lookup.common.ICommonLookup.MATCHING_MODE.UNIQUE_MATCH;

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<teamStruct> tHash_Lookup_team = org.talend.designer.components.lookup.memory.AdvancedMemoryLookup
						.<teamStruct>getLookup(matchingModeEnum_team);

				globalMap.put("tHash_Lookup_team", tHash_Lookup_team);

				/**
				 * [tAdvancedHash_team begin ] stop
				 */

				/**
				 * [tFileInputDelimited_2 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_2", false);
				start_Hash.put("tFileInputDelimited_2", System.currentTimeMillis());

				currentComponent = "tFileInputDelimited_2";

				int tos_count_tFileInputDelimited_2 = 0;

				final routines.system.RowState rowstate_tFileInputDelimited_2 = new routines.system.RowState();

				int nb_line_tFileInputDelimited_2 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_2 = null;
				int limit_tFileInputDelimited_2 = -1;
				try {

					Object filename_tFileInputDelimited_2 = "C:/Users/Thinkpad/Desktop/avg_team_by_player.csv";
					if (filename_tFileInputDelimited_2 instanceof java.io.InputStream) {

						int footer_value_tFileInputDelimited_2 = 0, random_value_tFileInputDelimited_2 = -1;
						if (footer_value_tFileInputDelimited_2 > 0 || random_value_tFileInputDelimited_2 > 0) {
							throw new java.lang.Exception(
									"When the input source is a stream,footer and random shouldn't be bigger than 0.");
						}

					}
					try {
						fid_tFileInputDelimited_2 = new org.talend.fileprocess.FileInputDelimited(
								"C:/Users/Thinkpad/Desktop/avg_team_by_player.csv", "US-ASCII", ";", "\n", false, 1, 0,
								limit_tFileInputDelimited_2, -1, false);
					} catch (java.lang.Exception e) {
						globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE", e.getMessage());

						System.err.println(e.getMessage());

					}

					while (fid_tFileInputDelimited_2 != null && fid_tFileInputDelimited_2.nextRecord()) {
						rowstate_tFileInputDelimited_2.reset();

						team = null;

						team = null;

						boolean whetherReject_tFileInputDelimited_2 = false;
						team = new teamStruct();
						try {

							int columnIndexWithD_tFileInputDelimited_2 = 0;

							String temp = "";

							columnIndexWithD_tFileInputDelimited_2 = 0;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									team.player_api_id = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"player_api_id", "team", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								team.player_api_id = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 1;

							team.player_name = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 2;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									team.team_api_id = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"team_api_id", "team", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								team.team_api_id = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 3;

							team.saison = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);

							columnIndexWithD_tFileInputDelimited_2 = 4;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									team.overall_rating = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"overall_rating", "team", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								team.overall_rating = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 5;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									team.potential = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"potential", "team", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								team.potential = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 6;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									team.finishing = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"finishing", "team", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								team.finishing = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 7;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									team.heading_accuracy = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"heading_accuracy", "team", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								team.heading_accuracy = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 8;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									team.short_passing = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"short_passing", "team", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								team.short_passing = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 9;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									team.dribbling = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"dribbling", "team", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								team.dribbling = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 10;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									team.sprint_speed = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"sprint_speed", "team", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								team.sprint_speed = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 11;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									team.balance = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"balance", "team", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								team.balance = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 12;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									team.shot_power = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"shot_power", "team", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								team.shot_power = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 13;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									team.jumping = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"jumping", "team", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								team.jumping = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 14;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									team.stamina = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"stamina", "team", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								team.stamina = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 15;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									team.strength = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"strength", "team", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								team.strength = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 16;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									team.positioning = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"positioning", "team", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								team.positioning = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 17;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									team.penalties = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"penalties", "team", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								team.penalties = null;

							}

							columnIndexWithD_tFileInputDelimited_2 = 18;

							temp = fid_tFileInputDelimited_2.get(columnIndexWithD_tFileInputDelimited_2);
							if (temp.length() > 0) {

								try {

									team.sliding_tackle = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_2) {
									globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE",
											ex_tFileInputDelimited_2.getMessage());
									rowstate_tFileInputDelimited_2.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"sliding_tackle", "team", temp, ex_tFileInputDelimited_2),
											ex_tFileInputDelimited_2));
								}

							} else {

								team.sliding_tackle = null;

							}

							if (rowstate_tFileInputDelimited_2.getException() != null) {
								throw rowstate_tFileInputDelimited_2.getException();
							}

						} catch (java.lang.Exception e) {
							globalMap.put("tFileInputDelimited_2_ERROR_MESSAGE", e.getMessage());
							whetherReject_tFileInputDelimited_2 = true;

							System.err.println(e.getMessage());
							team = null;

						}

						/**
						 * [tFileInputDelimited_2 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_2 main ] start
						 */

						currentComponent = "tFileInputDelimited_2";

						tos_count_tFileInputDelimited_2++;

						/**
						 * [tFileInputDelimited_2 main ] stop
						 */

						/**
						 * [tFileInputDelimited_2 process_data_begin ] start
						 */

						currentComponent = "tFileInputDelimited_2";

						/**
						 * [tFileInputDelimited_2 process_data_begin ] stop
						 */
// Start of branch "team"
						if (team != null) {

							/**
							 * [tAdvancedHash_team main ] start
							 */

							currentComponent = "tAdvancedHash_team";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "team"

								);
							}

							teamStruct team_HashRow = new teamStruct();

							team_HashRow.player_api_id = team.player_api_id;

							team_HashRow.player_name = team.player_name;

							team_HashRow.team_api_id = team.team_api_id;

							team_HashRow.saison = team.saison;

							team_HashRow.overall_rating = team.overall_rating;

							team_HashRow.potential = team.potential;

							team_HashRow.finishing = team.finishing;

							team_HashRow.heading_accuracy = team.heading_accuracy;

							team_HashRow.short_passing = team.short_passing;

							team_HashRow.dribbling = team.dribbling;

							team_HashRow.sprint_speed = team.sprint_speed;

							team_HashRow.balance = team.balance;

							team_HashRow.shot_power = team.shot_power;

							team_HashRow.jumping = team.jumping;

							team_HashRow.stamina = team.stamina;

							team_HashRow.strength = team.strength;

							team_HashRow.positioning = team.positioning;

							team_HashRow.penalties = team.penalties;

							team_HashRow.sliding_tackle = team.sliding_tackle;

							tHash_Lookup_team.put(team_HashRow);

							tos_count_tAdvancedHash_team++;

							/**
							 * [tAdvancedHash_team main ] stop
							 */

							/**
							 * [tAdvancedHash_team process_data_begin ] start
							 */

							currentComponent = "tAdvancedHash_team";

							/**
							 * [tAdvancedHash_team process_data_begin ] stop
							 */

							/**
							 * [tAdvancedHash_team process_data_end ] start
							 */

							currentComponent = "tAdvancedHash_team";

							/**
							 * [tAdvancedHash_team process_data_end ] stop
							 */

						} // End of branch "team"

						/**
						 * [tFileInputDelimited_2 process_data_end ] start
						 */

						currentComponent = "tFileInputDelimited_2";

						/**
						 * [tFileInputDelimited_2 process_data_end ] stop
						 */

						/**
						 * [tFileInputDelimited_2 end ] start
						 */

						currentComponent = "tFileInputDelimited_2";

					}
				} finally {
					if (!((Object) ("C:/Users/Thinkpad/Desktop/avg_team_by_player.csv") instanceof java.io.InputStream)) {
						if (fid_tFileInputDelimited_2 != null) {
							fid_tFileInputDelimited_2.close();
						}
					}
					if (fid_tFileInputDelimited_2 != null) {
						globalMap.put("tFileInputDelimited_2_NB_LINE", fid_tFileInputDelimited_2.getRowNumber());

					}
				}

				ok_Hash.put("tFileInputDelimited_2", true);
				end_Hash.put("tFileInputDelimited_2", System.currentTimeMillis());

				/**
				 * [tFileInputDelimited_2 end ] stop
				 */

				/**
				 * [tAdvancedHash_team end ] start
				 */

				currentComponent = "tAdvancedHash_team";

				tHash_Lookup_team.endPut();

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "team");
				}

				ok_Hash.put("tAdvancedHash_team", true);
				end_Hash.put("tAdvancedHash_team", System.currentTimeMillis());

				/**
				 * [tAdvancedHash_team end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tFileInputDelimited_2 finally ] start
				 */

				currentComponent = "tFileInputDelimited_2";

				/**
				 * [tFileInputDelimited_2 finally ] stop
				 */

				/**
				 * [tAdvancedHash_team finally ] start
				 */

				currentComponent = "tAdvancedHash_team";

				/**
				 * [tAdvancedHash_team finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_2_SUBPROCESS_STATE", 1);
	}

	public static class out1Struct implements routines.system.IPersistableRow<out1Struct> {
		final static byte[] commonByteArrayLock_EDD_PROJET_fusionnage_player_comparison = new byte[0];
		static byte[] commonByteArray_EDD_PROJET_fusionnage_player_comparison = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int player_api_id;

		public int getPlayer_api_id() {
			return this.player_api_id;
		}

		public String player_name;

		public String getPlayer_name() {
			return this.player_name;
		}

		public String saison;

		public String getSaison() {
			return this.saison;
		}

		public Float overall_rating;

		public Float getOverall_rating() {
			return this.overall_rating;
		}

		public Float potential;

		public Float getPotential() {
			return this.potential;
		}

		public Float finishing;

		public Float getFinishing() {
			return this.finishing;
		}

		public Float heading_accuracy;

		public Float getHeading_accuracy() {
			return this.heading_accuracy;
		}

		public Float short_passing;

		public Float getShort_passing() {
			return this.short_passing;
		}

		public Float dribbling;

		public Float getDribbling() {
			return this.dribbling;
		}

		public Float sprint_speed;

		public Float getSprint_speed() {
			return this.sprint_speed;
		}

		public Float balance;

		public Float getBalance() {
			return this.balance;
		}

		public Float shot_power;

		public Float getShot_power() {
			return this.shot_power;
		}

		public Float jumping;

		public Float getJumping() {
			return this.jumping;
		}

		public Float stamina;

		public Float getStamina() {
			return this.stamina;
		}

		public Float strength;

		public Float getStrength() {
			return this.strength;
		}

		public Float positioning;

		public Float getPositioning() {
			return this.positioning;
		}

		public Float penalties;

		public Float getPenalties() {
			return this.penalties;
		}

		public Float sliding_tackle;

		public Float getSliding_tackle() {
			return this.sliding_tackle;
		}

		public Float overall_rating_all;

		public Float getOverall_rating_all() {
			return this.overall_rating_all;
		}

		public Float potential_all;

		public Float getPotential_all() {
			return this.potential_all;
		}

		public Float finishing_all;

		public Float getFinishing_all() {
			return this.finishing_all;
		}

		public Float heading_accuracy_all;

		public Float getHeading_accuracy_all() {
			return this.heading_accuracy_all;
		}

		public Float short_passing_all;

		public Float getShort_passing_all() {
			return this.short_passing_all;
		}

		public Float dribbling_all;

		public Float getDribbling_all() {
			return this.dribbling_all;
		}

		public Float sprint_speed_all;

		public Float getSprint_speed_all() {
			return this.sprint_speed_all;
		}

		public Float balance_all;

		public Float getBalance_all() {
			return this.balance_all;
		}

		public Float shot_power_all;

		public Float getShot_power_all() {
			return this.shot_power_all;
		}

		public Float jumping_all;

		public Float getJumping_all() {
			return this.jumping_all;
		}

		public Float stamina_all;

		public Float getStamina_all() {
			return this.stamina_all;
		}

		public Float strength_all;

		public Float getStrength_all() {
			return this.strength_all;
		}

		public Float positioning_all;

		public Float getPositioning_all() {
			return this.positioning_all;
		}

		public Float penalties_all;

		public Float getPenalties_all() {
			return this.penalties_all;
		}

		public Float sliding_tackle_all;

		public Float getSliding_tackle_all() {
			return this.sliding_tackle_all;
		}

		public Float overall_rating_team;

		public Float getOverall_rating_team() {
			return this.overall_rating_team;
		}

		public Float potential_team;

		public Float getPotential_team() {
			return this.potential_team;
		}

		public Float finishing_team;

		public Float getFinishing_team() {
			return this.finishing_team;
		}

		public Float heading_accuracy_team;

		public Float getHeading_accuracy_team() {
			return this.heading_accuracy_team;
		}

		public Float short_passing_team;

		public Float getShort_passing_team() {
			return this.short_passing_team;
		}

		public Float dribbling_team;

		public Float getDribbling_team() {
			return this.dribbling_team;
		}

		public Float sprint_speed_team;

		public Float getSprint_speed_team() {
			return this.sprint_speed_team;
		}

		public Float balance_team;

		public Float getBalance_team() {
			return this.balance_team;
		}

		public Float shot_power_team;

		public Float getShot_power_team() {
			return this.shot_power_team;
		}

		public Float jumping_team;

		public Float getJumping_team() {
			return this.jumping_team;
		}

		public Float stamina_team;

		public Float getStamina_team() {
			return this.stamina_team;
		}

		public Float strength_team;

		public Float getStrength_team() {
			return this.strength_team;
		}

		public Float positioning_team;

		public Float getPositioning_team() {
			return this.positioning_team;
		}

		public Float penalties_team;

		public Float getPenalties_team() {
			return this.penalties_team;
		}

		public Float sliding_tackle_team;

		public Float getSliding_tackle_team() {
			return this.sliding_tackle_team;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.player_api_id;

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final out1Struct other = (out1Struct) obj;

			if (this.player_api_id != other.player_api_id)
				return false;

			return true;
		}

		public void copyDataTo(out1Struct other) {

			other.player_api_id = this.player_api_id;
			other.player_name = this.player_name;
			other.saison = this.saison;
			other.overall_rating = this.overall_rating;
			other.potential = this.potential;
			other.finishing = this.finishing;
			other.heading_accuracy = this.heading_accuracy;
			other.short_passing = this.short_passing;
			other.dribbling = this.dribbling;
			other.sprint_speed = this.sprint_speed;
			other.balance = this.balance;
			other.shot_power = this.shot_power;
			other.jumping = this.jumping;
			other.stamina = this.stamina;
			other.strength = this.strength;
			other.positioning = this.positioning;
			other.penalties = this.penalties;
			other.sliding_tackle = this.sliding_tackle;
			other.overall_rating_all = this.overall_rating_all;
			other.potential_all = this.potential_all;
			other.finishing_all = this.finishing_all;
			other.heading_accuracy_all = this.heading_accuracy_all;
			other.short_passing_all = this.short_passing_all;
			other.dribbling_all = this.dribbling_all;
			other.sprint_speed_all = this.sprint_speed_all;
			other.balance_all = this.balance_all;
			other.shot_power_all = this.shot_power_all;
			other.jumping_all = this.jumping_all;
			other.stamina_all = this.stamina_all;
			other.strength_all = this.strength_all;
			other.positioning_all = this.positioning_all;
			other.penalties_all = this.penalties_all;
			other.sliding_tackle_all = this.sliding_tackle_all;
			other.overall_rating_team = this.overall_rating_team;
			other.potential_team = this.potential_team;
			other.finishing_team = this.finishing_team;
			other.heading_accuracy_team = this.heading_accuracy_team;
			other.short_passing_team = this.short_passing_team;
			other.dribbling_team = this.dribbling_team;
			other.sprint_speed_team = this.sprint_speed_team;
			other.balance_team = this.balance_team;
			other.shot_power_team = this.shot_power_team;
			other.jumping_team = this.jumping_team;
			other.stamina_team = this.stamina_team;
			other.strength_team = this.strength_team;
			other.positioning_team = this.positioning_team;
			other.penalties_team = this.penalties_team;
			other.sliding_tackle_team = this.sliding_tackle_team;

		}

		public void copyKeysDataTo(out1Struct other) {

			other.player_api_id = this.player_api_id;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_EDD_PROJET_fusionnage_player_comparison.length) {
					if (length < 1024 && commonByteArray_EDD_PROJET_fusionnage_player_comparison.length == 0) {
						commonByteArray_EDD_PROJET_fusionnage_player_comparison = new byte[1024];
					} else {
						commonByteArray_EDD_PROJET_fusionnage_player_comparison = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_EDD_PROJET_fusionnage_player_comparison, 0, length);
				strReturn = new String(commonByteArray_EDD_PROJET_fusionnage_player_comparison, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_EDD_PROJET_fusionnage_player_comparison.length) {
					if (length < 1024 && commonByteArray_EDD_PROJET_fusionnage_player_comparison.length == 0) {
						commonByteArray_EDD_PROJET_fusionnage_player_comparison = new byte[1024];
					} else {
						commonByteArray_EDD_PROJET_fusionnage_player_comparison = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_EDD_PROJET_fusionnage_player_comparison, 0, length);
				strReturn = new String(commonByteArray_EDD_PROJET_fusionnage_player_comparison, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_EDD_PROJET_fusionnage_player_comparison) {

				try {

					int length = 0;

					this.player_api_id = dis.readInt();

					this.player_name = readString(dis);

					this.saison = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.overall_rating = null;
					} else {
						this.overall_rating = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.potential = null;
					} else {
						this.potential = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.finishing = null;
					} else {
						this.finishing = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.heading_accuracy = null;
					} else {
						this.heading_accuracy = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.short_passing = null;
					} else {
						this.short_passing = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.dribbling = null;
					} else {
						this.dribbling = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.sprint_speed = null;
					} else {
						this.sprint_speed = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.balance = null;
					} else {
						this.balance = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.shot_power = null;
					} else {
						this.shot_power = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.jumping = null;
					} else {
						this.jumping = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.stamina = null;
					} else {
						this.stamina = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.strength = null;
					} else {
						this.strength = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.positioning = null;
					} else {
						this.positioning = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.penalties = null;
					} else {
						this.penalties = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.sliding_tackle = null;
					} else {
						this.sliding_tackle = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.overall_rating_all = null;
					} else {
						this.overall_rating_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.potential_all = null;
					} else {
						this.potential_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.finishing_all = null;
					} else {
						this.finishing_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.heading_accuracy_all = null;
					} else {
						this.heading_accuracy_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.short_passing_all = null;
					} else {
						this.short_passing_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.dribbling_all = null;
					} else {
						this.dribbling_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.sprint_speed_all = null;
					} else {
						this.sprint_speed_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.balance_all = null;
					} else {
						this.balance_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.shot_power_all = null;
					} else {
						this.shot_power_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.jumping_all = null;
					} else {
						this.jumping_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.stamina_all = null;
					} else {
						this.stamina_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.strength_all = null;
					} else {
						this.strength_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.positioning_all = null;
					} else {
						this.positioning_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.penalties_all = null;
					} else {
						this.penalties_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.sliding_tackle_all = null;
					} else {
						this.sliding_tackle_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.overall_rating_team = null;
					} else {
						this.overall_rating_team = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.potential_team = null;
					} else {
						this.potential_team = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.finishing_team = null;
					} else {
						this.finishing_team = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.heading_accuracy_team = null;
					} else {
						this.heading_accuracy_team = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.short_passing_team = null;
					} else {
						this.short_passing_team = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.dribbling_team = null;
					} else {
						this.dribbling_team = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.sprint_speed_team = null;
					} else {
						this.sprint_speed_team = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.balance_team = null;
					} else {
						this.balance_team = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.shot_power_team = null;
					} else {
						this.shot_power_team = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.jumping_team = null;
					} else {
						this.jumping_team = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.stamina_team = null;
					} else {
						this.stamina_team = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.strength_team = null;
					} else {
						this.strength_team = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.positioning_team = null;
					} else {
						this.positioning_team = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.penalties_team = null;
					} else {
						this.penalties_team = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.sliding_tackle_team = null;
					} else {
						this.sliding_tackle_team = dis.readFloat();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_EDD_PROJET_fusionnage_player_comparison) {

				try {

					int length = 0;

					this.player_api_id = dis.readInt();

					this.player_name = readString(dis);

					this.saison = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.overall_rating = null;
					} else {
						this.overall_rating = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.potential = null;
					} else {
						this.potential = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.finishing = null;
					} else {
						this.finishing = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.heading_accuracy = null;
					} else {
						this.heading_accuracy = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.short_passing = null;
					} else {
						this.short_passing = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.dribbling = null;
					} else {
						this.dribbling = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.sprint_speed = null;
					} else {
						this.sprint_speed = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.balance = null;
					} else {
						this.balance = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.shot_power = null;
					} else {
						this.shot_power = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.jumping = null;
					} else {
						this.jumping = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.stamina = null;
					} else {
						this.stamina = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.strength = null;
					} else {
						this.strength = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.positioning = null;
					} else {
						this.positioning = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.penalties = null;
					} else {
						this.penalties = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.sliding_tackle = null;
					} else {
						this.sliding_tackle = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.overall_rating_all = null;
					} else {
						this.overall_rating_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.potential_all = null;
					} else {
						this.potential_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.finishing_all = null;
					} else {
						this.finishing_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.heading_accuracy_all = null;
					} else {
						this.heading_accuracy_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.short_passing_all = null;
					} else {
						this.short_passing_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.dribbling_all = null;
					} else {
						this.dribbling_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.sprint_speed_all = null;
					} else {
						this.sprint_speed_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.balance_all = null;
					} else {
						this.balance_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.shot_power_all = null;
					} else {
						this.shot_power_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.jumping_all = null;
					} else {
						this.jumping_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.stamina_all = null;
					} else {
						this.stamina_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.strength_all = null;
					} else {
						this.strength_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.positioning_all = null;
					} else {
						this.positioning_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.penalties_all = null;
					} else {
						this.penalties_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.sliding_tackle_all = null;
					} else {
						this.sliding_tackle_all = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.overall_rating_team = null;
					} else {
						this.overall_rating_team = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.potential_team = null;
					} else {
						this.potential_team = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.finishing_team = null;
					} else {
						this.finishing_team = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.heading_accuracy_team = null;
					} else {
						this.heading_accuracy_team = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.short_passing_team = null;
					} else {
						this.short_passing_team = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.dribbling_team = null;
					} else {
						this.dribbling_team = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.sprint_speed_team = null;
					} else {
						this.sprint_speed_team = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.balance_team = null;
					} else {
						this.balance_team = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.shot_power_team = null;
					} else {
						this.shot_power_team = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.jumping_team = null;
					} else {
						this.jumping_team = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.stamina_team = null;
					} else {
						this.stamina_team = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.strength_team = null;
					} else {
						this.strength_team = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.positioning_team = null;
					} else {
						this.positioning_team = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.penalties_team = null;
					} else {
						this.penalties_team = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.sliding_tackle_team = null;
					} else {
						this.sliding_tackle_team = dis.readFloat();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.player_api_id);

				// String

				writeString(this.player_name, dos);

				// String

				writeString(this.saison, dos);

				// Float

				if (this.overall_rating == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.overall_rating);
				}

				// Float

				if (this.potential == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.potential);
				}

				// Float

				if (this.finishing == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.finishing);
				}

				// Float

				if (this.heading_accuracy == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.heading_accuracy);
				}

				// Float

				if (this.short_passing == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.short_passing);
				}

				// Float

				if (this.dribbling == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.dribbling);
				}

				// Float

				if (this.sprint_speed == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.sprint_speed);
				}

				// Float

				if (this.balance == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.balance);
				}

				// Float

				if (this.shot_power == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.shot_power);
				}

				// Float

				if (this.jumping == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.jumping);
				}

				// Float

				if (this.stamina == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.stamina);
				}

				// Float

				if (this.strength == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.strength);
				}

				// Float

				if (this.positioning == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.positioning);
				}

				// Float

				if (this.penalties == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.penalties);
				}

				// Float

				if (this.sliding_tackle == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.sliding_tackle);
				}

				// Float

				if (this.overall_rating_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.overall_rating_all);
				}

				// Float

				if (this.potential_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.potential_all);
				}

				// Float

				if (this.finishing_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.finishing_all);
				}

				// Float

				if (this.heading_accuracy_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.heading_accuracy_all);
				}

				// Float

				if (this.short_passing_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.short_passing_all);
				}

				// Float

				if (this.dribbling_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.dribbling_all);
				}

				// Float

				if (this.sprint_speed_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.sprint_speed_all);
				}

				// Float

				if (this.balance_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.balance_all);
				}

				// Float

				if (this.shot_power_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.shot_power_all);
				}

				// Float

				if (this.jumping_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.jumping_all);
				}

				// Float

				if (this.stamina_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.stamina_all);
				}

				// Float

				if (this.strength_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.strength_all);
				}

				// Float

				if (this.positioning_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.positioning_all);
				}

				// Float

				if (this.penalties_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.penalties_all);
				}

				// Float

				if (this.sliding_tackle_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.sliding_tackle_all);
				}

				// Float

				if (this.overall_rating_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.overall_rating_team);
				}

				// Float

				if (this.potential_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.potential_team);
				}

				// Float

				if (this.finishing_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.finishing_team);
				}

				// Float

				if (this.heading_accuracy_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.heading_accuracy_team);
				}

				// Float

				if (this.short_passing_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.short_passing_team);
				}

				// Float

				if (this.dribbling_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.dribbling_team);
				}

				// Float

				if (this.sprint_speed_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.sprint_speed_team);
				}

				// Float

				if (this.balance_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.balance_team);
				}

				// Float

				if (this.shot_power_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.shot_power_team);
				}

				// Float

				if (this.jumping_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.jumping_team);
				}

				// Float

				if (this.stamina_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.stamina_team);
				}

				// Float

				if (this.strength_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.strength_team);
				}

				// Float

				if (this.positioning_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.positioning_team);
				}

				// Float

				if (this.penalties_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.penalties_team);
				}

				// Float

				if (this.sliding_tackle_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.sliding_tackle_team);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.player_api_id);

				// String

				writeString(this.player_name, dos);

				// String

				writeString(this.saison, dos);

				// Float

				if (this.overall_rating == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.overall_rating);
				}

				// Float

				if (this.potential == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.potential);
				}

				// Float

				if (this.finishing == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.finishing);
				}

				// Float

				if (this.heading_accuracy == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.heading_accuracy);
				}

				// Float

				if (this.short_passing == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.short_passing);
				}

				// Float

				if (this.dribbling == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.dribbling);
				}

				// Float

				if (this.sprint_speed == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.sprint_speed);
				}

				// Float

				if (this.balance == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.balance);
				}

				// Float

				if (this.shot_power == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.shot_power);
				}

				// Float

				if (this.jumping == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.jumping);
				}

				// Float

				if (this.stamina == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.stamina);
				}

				// Float

				if (this.strength == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.strength);
				}

				// Float

				if (this.positioning == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.positioning);
				}

				// Float

				if (this.penalties == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.penalties);
				}

				// Float

				if (this.sliding_tackle == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.sliding_tackle);
				}

				// Float

				if (this.overall_rating_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.overall_rating_all);
				}

				// Float

				if (this.potential_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.potential_all);
				}

				// Float

				if (this.finishing_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.finishing_all);
				}

				// Float

				if (this.heading_accuracy_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.heading_accuracy_all);
				}

				// Float

				if (this.short_passing_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.short_passing_all);
				}

				// Float

				if (this.dribbling_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.dribbling_all);
				}

				// Float

				if (this.sprint_speed_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.sprint_speed_all);
				}

				// Float

				if (this.balance_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.balance_all);
				}

				// Float

				if (this.shot_power_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.shot_power_all);
				}

				// Float

				if (this.jumping_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.jumping_all);
				}

				// Float

				if (this.stamina_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.stamina_all);
				}

				// Float

				if (this.strength_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.strength_all);
				}

				// Float

				if (this.positioning_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.positioning_all);
				}

				// Float

				if (this.penalties_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.penalties_all);
				}

				// Float

				if (this.sliding_tackle_all == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.sliding_tackle_all);
				}

				// Float

				if (this.overall_rating_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.overall_rating_team);
				}

				// Float

				if (this.potential_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.potential_team);
				}

				// Float

				if (this.finishing_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.finishing_team);
				}

				// Float

				if (this.heading_accuracy_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.heading_accuracy_team);
				}

				// Float

				if (this.short_passing_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.short_passing_team);
				}

				// Float

				if (this.dribbling_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.dribbling_team);
				}

				// Float

				if (this.sprint_speed_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.sprint_speed_team);
				}

				// Float

				if (this.balance_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.balance_team);
				}

				// Float

				if (this.shot_power_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.shot_power_team);
				}

				// Float

				if (this.jumping_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.jumping_team);
				}

				// Float

				if (this.stamina_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.stamina_team);
				}

				// Float

				if (this.strength_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.strength_team);
				}

				// Float

				if (this.positioning_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.positioning_team);
				}

				// Float

				if (this.penalties_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.penalties_team);
				}

				// Float

				if (this.sliding_tackle_team == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.sliding_tackle_team);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("player_api_id=" + String.valueOf(player_api_id));
			sb.append(",player_name=" + player_name);
			sb.append(",saison=" + saison);
			sb.append(",overall_rating=" + String.valueOf(overall_rating));
			sb.append(",potential=" + String.valueOf(potential));
			sb.append(",finishing=" + String.valueOf(finishing));
			sb.append(",heading_accuracy=" + String.valueOf(heading_accuracy));
			sb.append(",short_passing=" + String.valueOf(short_passing));
			sb.append(",dribbling=" + String.valueOf(dribbling));
			sb.append(",sprint_speed=" + String.valueOf(sprint_speed));
			sb.append(",balance=" + String.valueOf(balance));
			sb.append(",shot_power=" + String.valueOf(shot_power));
			sb.append(",jumping=" + String.valueOf(jumping));
			sb.append(",stamina=" + String.valueOf(stamina));
			sb.append(",strength=" + String.valueOf(strength));
			sb.append(",positioning=" + String.valueOf(positioning));
			sb.append(",penalties=" + String.valueOf(penalties));
			sb.append(",sliding_tackle=" + String.valueOf(sliding_tackle));
			sb.append(",overall_rating_all=" + String.valueOf(overall_rating_all));
			sb.append(",potential_all=" + String.valueOf(potential_all));
			sb.append(",finishing_all=" + String.valueOf(finishing_all));
			sb.append(",heading_accuracy_all=" + String.valueOf(heading_accuracy_all));
			sb.append(",short_passing_all=" + String.valueOf(short_passing_all));
			sb.append(",dribbling_all=" + String.valueOf(dribbling_all));
			sb.append(",sprint_speed_all=" + String.valueOf(sprint_speed_all));
			sb.append(",balance_all=" + String.valueOf(balance_all));
			sb.append(",shot_power_all=" + String.valueOf(shot_power_all));
			sb.append(",jumping_all=" + String.valueOf(jumping_all));
			sb.append(",stamina_all=" + String.valueOf(stamina_all));
			sb.append(",strength_all=" + String.valueOf(strength_all));
			sb.append(",positioning_all=" + String.valueOf(positioning_all));
			sb.append(",penalties_all=" + String.valueOf(penalties_all));
			sb.append(",sliding_tackle_all=" + String.valueOf(sliding_tackle_all));
			sb.append(",overall_rating_team=" + String.valueOf(overall_rating_team));
			sb.append(",potential_team=" + String.valueOf(potential_team));
			sb.append(",finishing_team=" + String.valueOf(finishing_team));
			sb.append(",heading_accuracy_team=" + String.valueOf(heading_accuracy_team));
			sb.append(",short_passing_team=" + String.valueOf(short_passing_team));
			sb.append(",dribbling_team=" + String.valueOf(dribbling_team));
			sb.append(",sprint_speed_team=" + String.valueOf(sprint_speed_team));
			sb.append(",balance_team=" + String.valueOf(balance_team));
			sb.append(",shot_power_team=" + String.valueOf(shot_power_team));
			sb.append(",jumping_team=" + String.valueOf(jumping_team));
			sb.append(",stamina_team=" + String.valueOf(stamina_team));
			sb.append(",strength_team=" + String.valueOf(strength_team));
			sb.append(",positioning_team=" + String.valueOf(positioning_team));
			sb.append(",penalties_team=" + String.valueOf(penalties_team));
			sb.append(",sliding_tackle_team=" + String.valueOf(sliding_tackle_team));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(out1Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.player_api_id, other.player_api_id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class playerStruct implements routines.system.IPersistableRow<playerStruct> {
		final static byte[] commonByteArrayLock_EDD_PROJET_fusionnage_player_comparison = new byte[0];
		static byte[] commonByteArray_EDD_PROJET_fusionnage_player_comparison = new byte[0];

		public int player_api_id;

		public int getPlayer_api_id() {
			return this.player_api_id;
		}

		public String player_name;

		public String getPlayer_name() {
			return this.player_name;
		}

		public String birthday;

		public String getBirthday() {
			return this.birthday;
		}

		public Float height;

		public Float getHeight() {
			return this.height;
		}

		public Integer weight;

		public Integer getWeight() {
			return this.weight;
		}

		public String saison;

		public String getSaison() {
			return this.saison;
		}

		public Float overall_rating;

		public Float getOverall_rating() {
			return this.overall_rating;
		}

		public Float potential;

		public Float getPotential() {
			return this.potential;
		}

		public Float finishing;

		public Float getFinishing() {
			return this.finishing;
		}

		public Float heading_accuracy;

		public Float getHeading_accuracy() {
			return this.heading_accuracy;
		}

		public Float short_passing;

		public Float getShort_passing() {
			return this.short_passing;
		}

		public Float dribbling;

		public Float getDribbling() {
			return this.dribbling;
		}

		public Float sprint_speed;

		public Float getSprint_speed() {
			return this.sprint_speed;
		}

		public Float balance;

		public Float getBalance() {
			return this.balance;
		}

		public Float shot_power;

		public Float getShot_power() {
			return this.shot_power;
		}

		public Float jumping;

		public Float getJumping() {
			return this.jumping;
		}

		public Float stamina;

		public Float getStamina() {
			return this.stamina;
		}

		public Float strength;

		public Float getStrength() {
			return this.strength;
		}

		public Float positioning;

		public Float getPositioning() {
			return this.positioning;
		}

		public Float penalties;

		public Float getPenalties() {
			return this.penalties;
		}

		public Float sliding_tackle;

		public Float getSliding_tackle() {
			return this.sliding_tackle;
		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_EDD_PROJET_fusionnage_player_comparison.length) {
					if (length < 1024 && commonByteArray_EDD_PROJET_fusionnage_player_comparison.length == 0) {
						commonByteArray_EDD_PROJET_fusionnage_player_comparison = new byte[1024];
					} else {
						commonByteArray_EDD_PROJET_fusionnage_player_comparison = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_EDD_PROJET_fusionnage_player_comparison, 0, length);
				strReturn = new String(commonByteArray_EDD_PROJET_fusionnage_player_comparison, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_EDD_PROJET_fusionnage_player_comparison.length) {
					if (length < 1024 && commonByteArray_EDD_PROJET_fusionnage_player_comparison.length == 0) {
						commonByteArray_EDD_PROJET_fusionnage_player_comparison = new byte[1024];
					} else {
						commonByteArray_EDD_PROJET_fusionnage_player_comparison = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_EDD_PROJET_fusionnage_player_comparison, 0, length);
				strReturn = new String(commonByteArray_EDD_PROJET_fusionnage_player_comparison, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_EDD_PROJET_fusionnage_player_comparison) {

				try {

					int length = 0;

					this.player_api_id = dis.readInt();

					this.player_name = readString(dis);

					this.birthday = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.height = null;
					} else {
						this.height = dis.readFloat();
					}

					this.weight = readInteger(dis);

					this.saison = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.overall_rating = null;
					} else {
						this.overall_rating = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.potential = null;
					} else {
						this.potential = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.finishing = null;
					} else {
						this.finishing = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.heading_accuracy = null;
					} else {
						this.heading_accuracy = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.short_passing = null;
					} else {
						this.short_passing = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.dribbling = null;
					} else {
						this.dribbling = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.sprint_speed = null;
					} else {
						this.sprint_speed = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.balance = null;
					} else {
						this.balance = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.shot_power = null;
					} else {
						this.shot_power = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.jumping = null;
					} else {
						this.jumping = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.stamina = null;
					} else {
						this.stamina = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.strength = null;
					} else {
						this.strength = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.positioning = null;
					} else {
						this.positioning = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.penalties = null;
					} else {
						this.penalties = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.sliding_tackle = null;
					} else {
						this.sliding_tackle = dis.readFloat();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_EDD_PROJET_fusionnage_player_comparison) {

				try {

					int length = 0;

					this.player_api_id = dis.readInt();

					this.player_name = readString(dis);

					this.birthday = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.height = null;
					} else {
						this.height = dis.readFloat();
					}

					this.weight = readInteger(dis);

					this.saison = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.overall_rating = null;
					} else {
						this.overall_rating = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.potential = null;
					} else {
						this.potential = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.finishing = null;
					} else {
						this.finishing = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.heading_accuracy = null;
					} else {
						this.heading_accuracy = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.short_passing = null;
					} else {
						this.short_passing = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.dribbling = null;
					} else {
						this.dribbling = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.sprint_speed = null;
					} else {
						this.sprint_speed = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.balance = null;
					} else {
						this.balance = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.shot_power = null;
					} else {
						this.shot_power = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.jumping = null;
					} else {
						this.jumping = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.stamina = null;
					} else {
						this.stamina = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.strength = null;
					} else {
						this.strength = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.positioning = null;
					} else {
						this.positioning = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.penalties = null;
					} else {
						this.penalties = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.sliding_tackle = null;
					} else {
						this.sliding_tackle = dis.readFloat();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.player_api_id);

				// String

				writeString(this.player_name, dos);

				// String

				writeString(this.birthday, dos);

				// Float

				if (this.height == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.height);
				}

				// Integer

				writeInteger(this.weight, dos);

				// String

				writeString(this.saison, dos);

				// Float

				if (this.overall_rating == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.overall_rating);
				}

				// Float

				if (this.potential == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.potential);
				}

				// Float

				if (this.finishing == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.finishing);
				}

				// Float

				if (this.heading_accuracy == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.heading_accuracy);
				}

				// Float

				if (this.short_passing == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.short_passing);
				}

				// Float

				if (this.dribbling == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.dribbling);
				}

				// Float

				if (this.sprint_speed == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.sprint_speed);
				}

				// Float

				if (this.balance == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.balance);
				}

				// Float

				if (this.shot_power == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.shot_power);
				}

				// Float

				if (this.jumping == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.jumping);
				}

				// Float

				if (this.stamina == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.stamina);
				}

				// Float

				if (this.strength == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.strength);
				}

				// Float

				if (this.positioning == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.positioning);
				}

				// Float

				if (this.penalties == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.penalties);
				}

				// Float

				if (this.sliding_tackle == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.sliding_tackle);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.player_api_id);

				// String

				writeString(this.player_name, dos);

				// String

				writeString(this.birthday, dos);

				// Float

				if (this.height == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.height);
				}

				// Integer

				writeInteger(this.weight, dos);

				// String

				writeString(this.saison, dos);

				// Float

				if (this.overall_rating == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.overall_rating);
				}

				// Float

				if (this.potential == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.potential);
				}

				// Float

				if (this.finishing == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.finishing);
				}

				// Float

				if (this.heading_accuracy == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.heading_accuracy);
				}

				// Float

				if (this.short_passing == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.short_passing);
				}

				// Float

				if (this.dribbling == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.dribbling);
				}

				// Float

				if (this.sprint_speed == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.sprint_speed);
				}

				// Float

				if (this.balance == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.balance);
				}

				// Float

				if (this.shot_power == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.shot_power);
				}

				// Float

				if (this.jumping == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.jumping);
				}

				// Float

				if (this.stamina == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.stamina);
				}

				// Float

				if (this.strength == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.strength);
				}

				// Float

				if (this.positioning == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.positioning);
				}

				// Float

				if (this.penalties == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.penalties);
				}

				// Float

				if (this.sliding_tackle == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.sliding_tackle);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("player_api_id=" + String.valueOf(player_api_id));
			sb.append(",player_name=" + player_name);
			sb.append(",birthday=" + birthday);
			sb.append(",height=" + String.valueOf(height));
			sb.append(",weight=" + String.valueOf(weight));
			sb.append(",saison=" + saison);
			sb.append(",overall_rating=" + String.valueOf(overall_rating));
			sb.append(",potential=" + String.valueOf(potential));
			sb.append(",finishing=" + String.valueOf(finishing));
			sb.append(",heading_accuracy=" + String.valueOf(heading_accuracy));
			sb.append(",short_passing=" + String.valueOf(short_passing));
			sb.append(",dribbling=" + String.valueOf(dribbling));
			sb.append(",sprint_speed=" + String.valueOf(sprint_speed));
			sb.append(",balance=" + String.valueOf(balance));
			sb.append(",shot_power=" + String.valueOf(shot_power));
			sb.append(",jumping=" + String.valueOf(jumping));
			sb.append(",stamina=" + String.valueOf(stamina));
			sb.append(",strength=" + String.valueOf(strength));
			sb.append(",positioning=" + String.valueOf(positioning));
			sb.append(",penalties=" + String.valueOf(penalties));
			sb.append(",sliding_tackle=" + String.valueOf(sliding_tackle));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(playerStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public static class after_tFileInputDelimited_3Struct
			implements routines.system.IPersistableRow<after_tFileInputDelimited_3Struct> {
		final static byte[] commonByteArrayLock_EDD_PROJET_fusionnage_player_comparison = new byte[0];
		static byte[] commonByteArray_EDD_PROJET_fusionnage_player_comparison = new byte[0];
		protected static final int DEFAULT_HASHCODE = 1;
		protected static final int PRIME = 31;
		protected int hashCode = DEFAULT_HASHCODE;
		public boolean hashCodeDirty = true;

		public String loopKey;

		public int player_api_id;

		public int getPlayer_api_id() {
			return this.player_api_id;
		}

		public String player_name;

		public String getPlayer_name() {
			return this.player_name;
		}

		public String birthday;

		public String getBirthday() {
			return this.birthday;
		}

		public Float height;

		public Float getHeight() {
			return this.height;
		}

		public Integer weight;

		public Integer getWeight() {
			return this.weight;
		}

		public String saison;

		public String getSaison() {
			return this.saison;
		}

		public Float overall_rating;

		public Float getOverall_rating() {
			return this.overall_rating;
		}

		public Float potential;

		public Float getPotential() {
			return this.potential;
		}

		public Float finishing;

		public Float getFinishing() {
			return this.finishing;
		}

		public Float heading_accuracy;

		public Float getHeading_accuracy() {
			return this.heading_accuracy;
		}

		public Float short_passing;

		public Float getShort_passing() {
			return this.short_passing;
		}

		public Float dribbling;

		public Float getDribbling() {
			return this.dribbling;
		}

		public Float sprint_speed;

		public Float getSprint_speed() {
			return this.sprint_speed;
		}

		public Float balance;

		public Float getBalance() {
			return this.balance;
		}

		public Float shot_power;

		public Float getShot_power() {
			return this.shot_power;
		}

		public Float jumping;

		public Float getJumping() {
			return this.jumping;
		}

		public Float stamina;

		public Float getStamina() {
			return this.stamina;
		}

		public Float strength;

		public Float getStrength() {
			return this.strength;
		}

		public Float positioning;

		public Float getPositioning() {
			return this.positioning;
		}

		public Float penalties;

		public Float getPenalties() {
			return this.penalties;
		}

		public Float sliding_tackle;

		public Float getSliding_tackle() {
			return this.sliding_tackle;
		}

		@Override
		public int hashCode() {
			if (this.hashCodeDirty) {
				final int prime = PRIME;
				int result = DEFAULT_HASHCODE;

				result = prime * result + (int) this.player_api_id;

				this.hashCode = result;
				this.hashCodeDirty = false;
			}
			return this.hashCode;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final after_tFileInputDelimited_3Struct other = (after_tFileInputDelimited_3Struct) obj;

			if (this.player_api_id != other.player_api_id)
				return false;

			return true;
		}

		public void copyDataTo(after_tFileInputDelimited_3Struct other) {

			other.player_api_id = this.player_api_id;
			other.player_name = this.player_name;
			other.birthday = this.birthday;
			other.height = this.height;
			other.weight = this.weight;
			other.saison = this.saison;
			other.overall_rating = this.overall_rating;
			other.potential = this.potential;
			other.finishing = this.finishing;
			other.heading_accuracy = this.heading_accuracy;
			other.short_passing = this.short_passing;
			other.dribbling = this.dribbling;
			other.sprint_speed = this.sprint_speed;
			other.balance = this.balance;
			other.shot_power = this.shot_power;
			other.jumping = this.jumping;
			other.stamina = this.stamina;
			other.strength = this.strength;
			other.positioning = this.positioning;
			other.penalties = this.penalties;
			other.sliding_tackle = this.sliding_tackle;

		}

		public void copyKeysDataTo(after_tFileInputDelimited_3Struct other) {

			other.player_api_id = this.player_api_id;

		}

		private String readString(ObjectInputStream dis) throws IOException {
			String strReturn = null;
			int length = 0;
			length = dis.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_EDD_PROJET_fusionnage_player_comparison.length) {
					if (length < 1024 && commonByteArray_EDD_PROJET_fusionnage_player_comparison.length == 0) {
						commonByteArray_EDD_PROJET_fusionnage_player_comparison = new byte[1024];
					} else {
						commonByteArray_EDD_PROJET_fusionnage_player_comparison = new byte[2 * length];
					}
				}
				dis.readFully(commonByteArray_EDD_PROJET_fusionnage_player_comparison, 0, length);
				strReturn = new String(commonByteArray_EDD_PROJET_fusionnage_player_comparison, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private String readString(org.jboss.marshalling.Unmarshaller unmarshaller) throws IOException {
			String strReturn = null;
			int length = 0;
			length = unmarshaller.readInt();
			if (length == -1) {
				strReturn = null;
			} else {
				if (length > commonByteArray_EDD_PROJET_fusionnage_player_comparison.length) {
					if (length < 1024 && commonByteArray_EDD_PROJET_fusionnage_player_comparison.length == 0) {
						commonByteArray_EDD_PROJET_fusionnage_player_comparison = new byte[1024];
					} else {
						commonByteArray_EDD_PROJET_fusionnage_player_comparison = new byte[2 * length];
					}
				}
				unmarshaller.readFully(commonByteArray_EDD_PROJET_fusionnage_player_comparison, 0, length);
				strReturn = new String(commonByteArray_EDD_PROJET_fusionnage_player_comparison, 0, length, utf8Charset);
			}
			return strReturn;
		}

		private void writeString(String str, ObjectOutputStream dos) throws IOException {
			if (str == null) {
				dos.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				dos.writeInt(byteArray.length);
				dos.write(byteArray);
			}
		}

		private void writeString(String str, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (str == null) {
				marshaller.writeInt(-1);
			} else {
				byte[] byteArray = str.getBytes(utf8Charset);
				marshaller.writeInt(byteArray.length);
				marshaller.write(byteArray);
			}
		}

		private Integer readInteger(ObjectInputStream dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private Integer readInteger(org.jboss.marshalling.Unmarshaller dis) throws IOException {
			Integer intReturn;
			int length = 0;
			length = dis.readByte();
			if (length == -1) {
				intReturn = null;
			} else {
				intReturn = dis.readInt();
			}
			return intReturn;
		}

		private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException {
			if (intNum == null) {
				dos.writeByte(-1);
			} else {
				dos.writeByte(0);
				dos.writeInt(intNum);
			}
		}

		private void writeInteger(Integer intNum, org.jboss.marshalling.Marshaller marshaller) throws IOException {
			if (intNum == null) {
				marshaller.writeByte(-1);
			} else {
				marshaller.writeByte(0);
				marshaller.writeInt(intNum);
			}
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock_EDD_PROJET_fusionnage_player_comparison) {

				try {

					int length = 0;

					this.player_api_id = dis.readInt();

					this.player_name = readString(dis);

					this.birthday = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.height = null;
					} else {
						this.height = dis.readFloat();
					}

					this.weight = readInteger(dis);

					this.saison = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.overall_rating = null;
					} else {
						this.overall_rating = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.potential = null;
					} else {
						this.potential = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.finishing = null;
					} else {
						this.finishing = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.heading_accuracy = null;
					} else {
						this.heading_accuracy = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.short_passing = null;
					} else {
						this.short_passing = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.dribbling = null;
					} else {
						this.dribbling = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.sprint_speed = null;
					} else {
						this.sprint_speed = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.balance = null;
					} else {
						this.balance = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.shot_power = null;
					} else {
						this.shot_power = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.jumping = null;
					} else {
						this.jumping = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.stamina = null;
					} else {
						this.stamina = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.strength = null;
					} else {
						this.strength = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.positioning = null;
					} else {
						this.positioning = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.penalties = null;
					} else {
						this.penalties = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.sliding_tackle = null;
					} else {
						this.sliding_tackle = dis.readFloat();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void readData(org.jboss.marshalling.Unmarshaller dis) {

			synchronized (commonByteArrayLock_EDD_PROJET_fusionnage_player_comparison) {

				try {

					int length = 0;

					this.player_api_id = dis.readInt();

					this.player_name = readString(dis);

					this.birthday = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.height = null;
					} else {
						this.height = dis.readFloat();
					}

					this.weight = readInteger(dis);

					this.saison = readString(dis);

					length = dis.readByte();
					if (length == -1) {
						this.overall_rating = null;
					} else {
						this.overall_rating = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.potential = null;
					} else {
						this.potential = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.finishing = null;
					} else {
						this.finishing = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.heading_accuracy = null;
					} else {
						this.heading_accuracy = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.short_passing = null;
					} else {
						this.short_passing = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.dribbling = null;
					} else {
						this.dribbling = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.sprint_speed = null;
					} else {
						this.sprint_speed = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.balance = null;
					} else {
						this.balance = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.shot_power = null;
					} else {
						this.shot_power = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.jumping = null;
					} else {
						this.jumping = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.stamina = null;
					} else {
						this.stamina = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.strength = null;
					} else {
						this.strength = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.positioning = null;
					} else {
						this.positioning = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.penalties = null;
					} else {
						this.penalties = dis.readFloat();
					}

					length = dis.readByte();
					if (length == -1) {
						this.sliding_tackle = null;
					} else {
						this.sliding_tackle = dis.readFloat();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// int

				dos.writeInt(this.player_api_id);

				// String

				writeString(this.player_name, dos);

				// String

				writeString(this.birthday, dos);

				// Float

				if (this.height == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.height);
				}

				// Integer

				writeInteger(this.weight, dos);

				// String

				writeString(this.saison, dos);

				// Float

				if (this.overall_rating == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.overall_rating);
				}

				// Float

				if (this.potential == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.potential);
				}

				// Float

				if (this.finishing == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.finishing);
				}

				// Float

				if (this.heading_accuracy == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.heading_accuracy);
				}

				// Float

				if (this.short_passing == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.short_passing);
				}

				// Float

				if (this.dribbling == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.dribbling);
				}

				// Float

				if (this.sprint_speed == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.sprint_speed);
				}

				// Float

				if (this.balance == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.balance);
				}

				// Float

				if (this.shot_power == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.shot_power);
				}

				// Float

				if (this.jumping == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.jumping);
				}

				// Float

				if (this.stamina == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.stamina);
				}

				// Float

				if (this.strength == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.strength);
				}

				// Float

				if (this.positioning == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.positioning);
				}

				// Float

				if (this.penalties == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.penalties);
				}

				// Float

				if (this.sliding_tackle == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.sliding_tackle);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public void writeData(org.jboss.marshalling.Marshaller dos) {
			try {

				// int

				dos.writeInt(this.player_api_id);

				// String

				writeString(this.player_name, dos);

				// String

				writeString(this.birthday, dos);

				// Float

				if (this.height == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.height);
				}

				// Integer

				writeInteger(this.weight, dos);

				// String

				writeString(this.saison, dos);

				// Float

				if (this.overall_rating == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.overall_rating);
				}

				// Float

				if (this.potential == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.potential);
				}

				// Float

				if (this.finishing == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.finishing);
				}

				// Float

				if (this.heading_accuracy == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.heading_accuracy);
				}

				// Float

				if (this.short_passing == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.short_passing);
				}

				// Float

				if (this.dribbling == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.dribbling);
				}

				// Float

				if (this.sprint_speed == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.sprint_speed);
				}

				// Float

				if (this.balance == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.balance);
				}

				// Float

				if (this.shot_power == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.shot_power);
				}

				// Float

				if (this.jumping == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.jumping);
				}

				// Float

				if (this.stamina == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.stamina);
				}

				// Float

				if (this.strength == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.strength);
				}

				// Float

				if (this.positioning == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.positioning);
				}

				// Float

				if (this.penalties == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.penalties);
				}

				// Float

				if (this.sliding_tackle == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeFloat(this.sliding_tackle);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");
			sb.append("player_api_id=" + String.valueOf(player_api_id));
			sb.append(",player_name=" + player_name);
			sb.append(",birthday=" + birthday);
			sb.append(",height=" + String.valueOf(height));
			sb.append(",weight=" + String.valueOf(weight));
			sb.append(",saison=" + saison);
			sb.append(",overall_rating=" + String.valueOf(overall_rating));
			sb.append(",potential=" + String.valueOf(potential));
			sb.append(",finishing=" + String.valueOf(finishing));
			sb.append(",heading_accuracy=" + String.valueOf(heading_accuracy));
			sb.append(",short_passing=" + String.valueOf(short_passing));
			sb.append(",dribbling=" + String.valueOf(dribbling));
			sb.append(",sprint_speed=" + String.valueOf(sprint_speed));
			sb.append(",balance=" + String.valueOf(balance));
			sb.append(",shot_power=" + String.valueOf(shot_power));
			sb.append(",jumping=" + String.valueOf(jumping));
			sb.append(",stamina=" + String.valueOf(stamina));
			sb.append(",strength=" + String.valueOf(strength));
			sb.append(",positioning=" + String.valueOf(positioning));
			sb.append(",penalties=" + String.valueOf(penalties));
			sb.append(",sliding_tackle=" + String.valueOf(sliding_tackle));
			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(after_tFileInputDelimited_3Struct other) {

			int returnValue = -1;

			returnValue = checkNullsAndCompare(this.player_api_id, other.player_api_id);
			if (returnValue != 0) {
				return returnValue;
			}

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileInputDelimited_3_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				tFileInputDelimited_1Process(globalMap);
				tFileInputDelimited_2Process(globalMap);

				playerStruct player = new playerStruct();
				out1Struct out1 = new out1Struct();

				/**
				 * [tFileOutputExcel_1 begin ] start
				 */

				ok_Hash.put("tFileOutputExcel_1", false);
				start_Hash.put("tFileOutputExcel_1", System.currentTimeMillis());

				currentComponent = "tFileOutputExcel_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "out1");
				}

				int tos_count_tFileOutputExcel_1 = 0;

				int columnIndex_tFileOutputExcel_1 = 0;
				boolean headerIsInserted_tFileOutputExcel_1 = false;

				int nb_line_tFileOutputExcel_1 = 0;

				String fileName_tFileOutputExcel_1 = "C:/Users/Thinkpad/Desktop/analyse_player_perfor.xls";
				java.io.File file_tFileOutputExcel_1 = new java.io.File(fileName_tFileOutputExcel_1);
				boolean isFileGenerated_tFileOutputExcel_1 = true;
//create directory only if not exists
				java.io.File parentFile_tFileOutputExcel_1 = file_tFileOutputExcel_1.getParentFile();
				if (parentFile_tFileOutputExcel_1 != null && !parentFile_tFileOutputExcel_1.exists()) {

					parentFile_tFileOutputExcel_1.mkdirs();

				}

				jxl.write.WritableWorkbook writeableWorkbook_tFileOutputExcel_1 = null;
				jxl.write.WritableSheet writableSheet_tFileOutputExcel_1 = null;

				jxl.WorkbookSettings workbookSettings_tFileOutputExcel_1 = new jxl.WorkbookSettings();
				workbookSettings_tFileOutputExcel_1.setEncoding("ISO-8859-15");
				writeableWorkbook_tFileOutputExcel_1 = new jxl.write.biff.WritableWorkbookImpl(
						new java.io.BufferedOutputStream(new java.io.FileOutputStream(fileName_tFileOutputExcel_1)),
						true, workbookSettings_tFileOutputExcel_1);

				writableSheet_tFileOutputExcel_1 = writeableWorkbook_tFileOutputExcel_1.getSheet("Sheet1");
				if (writableSheet_tFileOutputExcel_1 == null) {
					writableSheet_tFileOutputExcel_1 = writeableWorkbook_tFileOutputExcel_1.createSheet("Sheet1",
							writeableWorkbook_tFileOutputExcel_1.getNumberOfSheets());
				}

				// modif start
				int startRowNum_tFileOutputExcel_1 = writableSheet_tFileOutputExcel_1.getRows();
				// modif end

				int[] fitWidth_tFileOutputExcel_1 = new int[48];
				for (int i_tFileOutputExcel_1 = 0; i_tFileOutputExcel_1 < 48; i_tFileOutputExcel_1++) {
					int fitCellViewSize_tFileOutputExcel_1 = writableSheet_tFileOutputExcel_1
							.getColumnView(i_tFileOutputExcel_1).getSize();
					fitWidth_tFileOutputExcel_1[i_tFileOutputExcel_1] = fitCellViewSize_tFileOutputExcel_1 / 256;
					if (fitCellViewSize_tFileOutputExcel_1 % 256 != 0) {
						fitWidth_tFileOutputExcel_1[i_tFileOutputExcel_1] += 1;
					}
				}

				if (startRowNum_tFileOutputExcel_1 == 0) {
					// modif end
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(0, nb_line_tFileOutputExcel_1, "player_api_id"));
					// modif end
					fitWidth_tFileOutputExcel_1[0] = fitWidth_tFileOutputExcel_1[0] > 13
							? fitWidth_tFileOutputExcel_1[0]
							: 13;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(1, nb_line_tFileOutputExcel_1, "player_name"));
					// modif end
					fitWidth_tFileOutputExcel_1[1] = fitWidth_tFileOutputExcel_1[1] > 11
							? fitWidth_tFileOutputExcel_1[1]
							: 11;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(2, nb_line_tFileOutputExcel_1, "saison"));
					// modif end
					fitWidth_tFileOutputExcel_1[2] = fitWidth_tFileOutputExcel_1[2] > 6 ? fitWidth_tFileOutputExcel_1[2]
							: 6;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(3, nb_line_tFileOutputExcel_1, "overall_rating"));
					// modif end
					fitWidth_tFileOutputExcel_1[3] = fitWidth_tFileOutputExcel_1[3] > 14
							? fitWidth_tFileOutputExcel_1[3]
							: 14;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(4, nb_line_tFileOutputExcel_1, "potential"));
					// modif end
					fitWidth_tFileOutputExcel_1[4] = fitWidth_tFileOutputExcel_1[4] > 9 ? fitWidth_tFileOutputExcel_1[4]
							: 9;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(5, nb_line_tFileOutputExcel_1, "finishing"));
					// modif end
					fitWidth_tFileOutputExcel_1[5] = fitWidth_tFileOutputExcel_1[5] > 9 ? fitWidth_tFileOutputExcel_1[5]
							: 9;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(6, nb_line_tFileOutputExcel_1, "heading_accuracy"));
					// modif end
					fitWidth_tFileOutputExcel_1[6] = fitWidth_tFileOutputExcel_1[6] > 16
							? fitWidth_tFileOutputExcel_1[6]
							: 16;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(7, nb_line_tFileOutputExcel_1, "short_passing"));
					// modif end
					fitWidth_tFileOutputExcel_1[7] = fitWidth_tFileOutputExcel_1[7] > 13
							? fitWidth_tFileOutputExcel_1[7]
							: 13;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(8, nb_line_tFileOutputExcel_1, "dribbling"));
					// modif end
					fitWidth_tFileOutputExcel_1[8] = fitWidth_tFileOutputExcel_1[8] > 9 ? fitWidth_tFileOutputExcel_1[8]
							: 9;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(9, nb_line_tFileOutputExcel_1, "sprint_speed"));
					// modif end
					fitWidth_tFileOutputExcel_1[9] = fitWidth_tFileOutputExcel_1[9] > 12
							? fitWidth_tFileOutputExcel_1[9]
							: 12;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(10, nb_line_tFileOutputExcel_1, "balance"));
					// modif end
					fitWidth_tFileOutputExcel_1[10] = fitWidth_tFileOutputExcel_1[10] > 7
							? fitWidth_tFileOutputExcel_1[10]
							: 7;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(11, nb_line_tFileOutputExcel_1, "shot_power"));
					// modif end
					fitWidth_tFileOutputExcel_1[11] = fitWidth_tFileOutputExcel_1[11] > 10
							? fitWidth_tFileOutputExcel_1[11]
							: 10;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(12, nb_line_tFileOutputExcel_1, "jumping"));
					// modif end
					fitWidth_tFileOutputExcel_1[12] = fitWidth_tFileOutputExcel_1[12] > 7
							? fitWidth_tFileOutputExcel_1[12]
							: 7;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(13, nb_line_tFileOutputExcel_1, "stamina"));
					// modif end
					fitWidth_tFileOutputExcel_1[13] = fitWidth_tFileOutputExcel_1[13] > 7
							? fitWidth_tFileOutputExcel_1[13]
							: 7;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(14, nb_line_tFileOutputExcel_1, "strength"));
					// modif end
					fitWidth_tFileOutputExcel_1[14] = fitWidth_tFileOutputExcel_1[14] > 8
							? fitWidth_tFileOutputExcel_1[14]
							: 8;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(15, nb_line_tFileOutputExcel_1, "positioning"));
					// modif end
					fitWidth_tFileOutputExcel_1[15] = fitWidth_tFileOutputExcel_1[15] > 11
							? fitWidth_tFileOutputExcel_1[15]
							: 11;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(16, nb_line_tFileOutputExcel_1, "penalties"));
					// modif end
					fitWidth_tFileOutputExcel_1[16] = fitWidth_tFileOutputExcel_1[16] > 9
							? fitWidth_tFileOutputExcel_1[16]
							: 9;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(17, nb_line_tFileOutputExcel_1, "sliding_tackle"));
					// modif end
					fitWidth_tFileOutputExcel_1[17] = fitWidth_tFileOutputExcel_1[17] > 14
							? fitWidth_tFileOutputExcel_1[17]
							: 14;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(18, nb_line_tFileOutputExcel_1, "overall_rating_all"));
					// modif end
					fitWidth_tFileOutputExcel_1[18] = fitWidth_tFileOutputExcel_1[18] > 18
							? fitWidth_tFileOutputExcel_1[18]
							: 18;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(19, nb_line_tFileOutputExcel_1, "potential_all"));
					// modif end
					fitWidth_tFileOutputExcel_1[19] = fitWidth_tFileOutputExcel_1[19] > 13
							? fitWidth_tFileOutputExcel_1[19]
							: 13;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(20, nb_line_tFileOutputExcel_1, "finishing_all"));
					// modif end
					fitWidth_tFileOutputExcel_1[20] = fitWidth_tFileOutputExcel_1[20] > 13
							? fitWidth_tFileOutputExcel_1[20]
							: 13;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(21, nb_line_tFileOutputExcel_1, "heading_accuracy_all"));
					// modif end
					fitWidth_tFileOutputExcel_1[21] = fitWidth_tFileOutputExcel_1[21] > 20
							? fitWidth_tFileOutputExcel_1[21]
							: 20;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(22, nb_line_tFileOutputExcel_1, "short_passing_all"));
					// modif end
					fitWidth_tFileOutputExcel_1[22] = fitWidth_tFileOutputExcel_1[22] > 17
							? fitWidth_tFileOutputExcel_1[22]
							: 17;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(23, nb_line_tFileOutputExcel_1, "dribbling_all"));
					// modif end
					fitWidth_tFileOutputExcel_1[23] = fitWidth_tFileOutputExcel_1[23] > 13
							? fitWidth_tFileOutputExcel_1[23]
							: 13;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(24, nb_line_tFileOutputExcel_1, "sprint_speed_all"));
					// modif end
					fitWidth_tFileOutputExcel_1[24] = fitWidth_tFileOutputExcel_1[24] > 16
							? fitWidth_tFileOutputExcel_1[24]
							: 16;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(25, nb_line_tFileOutputExcel_1, "balance_all"));
					// modif end
					fitWidth_tFileOutputExcel_1[25] = fitWidth_tFileOutputExcel_1[25] > 11
							? fitWidth_tFileOutputExcel_1[25]
							: 11;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(26, nb_line_tFileOutputExcel_1, "shot_power_all"));
					// modif end
					fitWidth_tFileOutputExcel_1[26] = fitWidth_tFileOutputExcel_1[26] > 14
							? fitWidth_tFileOutputExcel_1[26]
							: 14;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(27, nb_line_tFileOutputExcel_1, "jumping_all"));
					// modif end
					fitWidth_tFileOutputExcel_1[27] = fitWidth_tFileOutputExcel_1[27] > 11
							? fitWidth_tFileOutputExcel_1[27]
							: 11;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(28, nb_line_tFileOutputExcel_1, "stamina_all"));
					// modif end
					fitWidth_tFileOutputExcel_1[28] = fitWidth_tFileOutputExcel_1[28] > 11
							? fitWidth_tFileOutputExcel_1[28]
							: 11;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(29, nb_line_tFileOutputExcel_1, "strength_all"));
					// modif end
					fitWidth_tFileOutputExcel_1[29] = fitWidth_tFileOutputExcel_1[29] > 12
							? fitWidth_tFileOutputExcel_1[29]
							: 12;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(30, nb_line_tFileOutputExcel_1, "positioning_all"));
					// modif end
					fitWidth_tFileOutputExcel_1[30] = fitWidth_tFileOutputExcel_1[30] > 15
							? fitWidth_tFileOutputExcel_1[30]
							: 15;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(31, nb_line_tFileOutputExcel_1, "penalties_all"));
					// modif end
					fitWidth_tFileOutputExcel_1[31] = fitWidth_tFileOutputExcel_1[31] > 13
							? fitWidth_tFileOutputExcel_1[31]
							: 13;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(32, nb_line_tFileOutputExcel_1, "sliding_tackle_all"));
					// modif end
					fitWidth_tFileOutputExcel_1[32] = fitWidth_tFileOutputExcel_1[32] > 18
							? fitWidth_tFileOutputExcel_1[32]
							: 18;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(33, nb_line_tFileOutputExcel_1, "overall_rating_team"));
					// modif end
					fitWidth_tFileOutputExcel_1[33] = fitWidth_tFileOutputExcel_1[33] > 19
							? fitWidth_tFileOutputExcel_1[33]
							: 19;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(34, nb_line_tFileOutputExcel_1, "potential_team"));
					// modif end
					fitWidth_tFileOutputExcel_1[34] = fitWidth_tFileOutputExcel_1[34] > 14
							? fitWidth_tFileOutputExcel_1[34]
							: 14;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(35, nb_line_tFileOutputExcel_1, "finishing_team"));
					// modif end
					fitWidth_tFileOutputExcel_1[35] = fitWidth_tFileOutputExcel_1[35] > 14
							? fitWidth_tFileOutputExcel_1[35]
							: 14;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(36, nb_line_tFileOutputExcel_1, "heading_accuracy_team"));
					// modif end
					fitWidth_tFileOutputExcel_1[36] = fitWidth_tFileOutputExcel_1[36] > 21
							? fitWidth_tFileOutputExcel_1[36]
							: 21;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(37, nb_line_tFileOutputExcel_1, "short_passing_team"));
					// modif end
					fitWidth_tFileOutputExcel_1[37] = fitWidth_tFileOutputExcel_1[37] > 18
							? fitWidth_tFileOutputExcel_1[37]
							: 18;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(38, nb_line_tFileOutputExcel_1, "dribbling_team"));
					// modif end
					fitWidth_tFileOutputExcel_1[38] = fitWidth_tFileOutputExcel_1[38] > 14
							? fitWidth_tFileOutputExcel_1[38]
							: 14;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(39, nb_line_tFileOutputExcel_1, "sprint_speed_team"));
					// modif end
					fitWidth_tFileOutputExcel_1[39] = fitWidth_tFileOutputExcel_1[39] > 17
							? fitWidth_tFileOutputExcel_1[39]
							: 17;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(40, nb_line_tFileOutputExcel_1, "balance_team"));
					// modif end
					fitWidth_tFileOutputExcel_1[40] = fitWidth_tFileOutputExcel_1[40] > 12
							? fitWidth_tFileOutputExcel_1[40]
							: 12;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(41, nb_line_tFileOutputExcel_1, "shot_power_team"));
					// modif end
					fitWidth_tFileOutputExcel_1[41] = fitWidth_tFileOutputExcel_1[41] > 15
							? fitWidth_tFileOutputExcel_1[41]
							: 15;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(42, nb_line_tFileOutputExcel_1, "jumping_team"));
					// modif end
					fitWidth_tFileOutputExcel_1[42] = fitWidth_tFileOutputExcel_1[42] > 12
							? fitWidth_tFileOutputExcel_1[42]
							: 12;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(43, nb_line_tFileOutputExcel_1, "stamina_team"));
					// modif end
					fitWidth_tFileOutputExcel_1[43] = fitWidth_tFileOutputExcel_1[43] > 12
							? fitWidth_tFileOutputExcel_1[43]
							: 12;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(44, nb_line_tFileOutputExcel_1, "strength_team"));
					// modif end
					fitWidth_tFileOutputExcel_1[44] = fitWidth_tFileOutputExcel_1[44] > 13
							? fitWidth_tFileOutputExcel_1[44]
							: 13;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(45, nb_line_tFileOutputExcel_1, "positioning_team"));
					// modif end
					fitWidth_tFileOutputExcel_1[45] = fitWidth_tFileOutputExcel_1[45] > 16
							? fitWidth_tFileOutputExcel_1[45]
							: 16;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(46, nb_line_tFileOutputExcel_1, "penalties_team"));
					// modif end
					fitWidth_tFileOutputExcel_1[46] = fitWidth_tFileOutputExcel_1[46] > 14
							? fitWidth_tFileOutputExcel_1[46]
							: 14;
					// modif start
					writableSheet_tFileOutputExcel_1
							.addCell(new jxl.write.Label(47, nb_line_tFileOutputExcel_1, "sliding_tackle_team"));
					// modif end
					fitWidth_tFileOutputExcel_1[47] = fitWidth_tFileOutputExcel_1[47] > 19
							? fitWidth_tFileOutputExcel_1[47]
							: 19;
					nb_line_tFileOutputExcel_1++;
					headerIsInserted_tFileOutputExcel_1 = true;
				}

				/**
				 * [tFileOutputExcel_1 begin ] stop
				 */

				/**
				 * [tMap_1 begin ] start
				 */

				ok_Hash.put("tMap_1", false);
				start_Hash.put("tMap_1", System.currentTimeMillis());

				currentComponent = "tMap_1";

				if (execStat) {
					runStat.updateStatOnConnection(resourceMap, iterateId, 0, 0, "player");
				}

				int tos_count_tMap_1 = 0;

// ###############################
// # Lookup's keys initialization

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<allStruct> tHash_Lookup_all = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<allStruct>) ((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<allStruct>) globalMap
						.get("tHash_Lookup_all"));

				allStruct allHashKey = new allStruct();
				allStruct allDefault = new allStruct();

				org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<teamStruct> tHash_Lookup_team = (org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<teamStruct>) ((org.talend.designer.components.lookup.memory.AdvancedMemoryLookup<teamStruct>) globalMap
						.get("tHash_Lookup_team"));

				teamStruct teamHashKey = new teamStruct();
				teamStruct teamDefault = new teamStruct();
// ###############################        

// ###############################
// # Vars initialization
				class Var__tMap_1__Struct {
				}
				Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				out1Struct out1_tmp = new out1Struct();
// ###############################

				/**
				 * [tMap_1 begin ] stop
				 */

				/**
				 * [tFileInputDelimited_3 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_3", false);
				start_Hash.put("tFileInputDelimited_3", System.currentTimeMillis());

				currentComponent = "tFileInputDelimited_3";

				int tos_count_tFileInputDelimited_3 = 0;

				final routines.system.RowState rowstate_tFileInputDelimited_3 = new routines.system.RowState();

				int nb_line_tFileInputDelimited_3 = 0;
				org.talend.fileprocess.FileInputDelimited fid_tFileInputDelimited_3 = null;
				int limit_tFileInputDelimited_3 = -1;
				try {

					Object filename_tFileInputDelimited_3 = "C:/Users/Thinkpad/Desktop/PLAYER.csv";
					if (filename_tFileInputDelimited_3 instanceof java.io.InputStream) {

						int footer_value_tFileInputDelimited_3 = 0, random_value_tFileInputDelimited_3 = -1;
						if (footer_value_tFileInputDelimited_3 > 0 || random_value_tFileInputDelimited_3 > 0) {
							throw new java.lang.Exception(
									"When the input source is a stream,footer and random shouldn't be bigger than 0.");
						}

					}
					try {
						fid_tFileInputDelimited_3 = new org.talend.fileprocess.FileInputDelimited(
								"C:/Users/Thinkpad/Desktop/PLAYER.csv", "US-ASCII", ";", "\n", false, 1, 0,
								limit_tFileInputDelimited_3, -1, false);
					} catch (java.lang.Exception e) {
						globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE", e.getMessage());

						System.err.println(e.getMessage());

					}

					while (fid_tFileInputDelimited_3 != null && fid_tFileInputDelimited_3.nextRecord()) {
						rowstate_tFileInputDelimited_3.reset();

						player = null;

						boolean whetherReject_tFileInputDelimited_3 = false;
						player = new playerStruct();
						try {

							int columnIndexWithD_tFileInputDelimited_3 = 0;

							String temp = "";

							columnIndexWithD_tFileInputDelimited_3 = 0;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									player.player_api_id = ParserUtils.parseTo_int(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"player_api_id", "player", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								rowstate_tFileInputDelimited_3.setException(new RuntimeException(
										"Value is empty for column : 'player_api_id' in 'player' connection, value is invalid or this column should be nullable or have a default value."));

							}

							columnIndexWithD_tFileInputDelimited_3 = 1;

							player.player_name = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);

							columnIndexWithD_tFileInputDelimited_3 = 2;

							player.birthday = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);

							columnIndexWithD_tFileInputDelimited_3 = 3;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									player.height = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"height", "player", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								player.height = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 4;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									player.weight = ParserUtils.parseTo_Integer(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"weight", "player", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								player.weight = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 5;

							player.saison = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);

							columnIndexWithD_tFileInputDelimited_3 = 6;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									player.overall_rating = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"overall_rating", "player", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								player.overall_rating = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 7;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									player.potential = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"potential", "player", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								player.potential = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 8;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									player.finishing = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"finishing", "player", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								player.finishing = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 9;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									player.heading_accuracy = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"heading_accuracy", "player", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								player.heading_accuracy = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 10;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									player.short_passing = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"short_passing", "player", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								player.short_passing = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 11;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									player.dribbling = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"dribbling", "player", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								player.dribbling = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 12;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									player.sprint_speed = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"sprint_speed", "player", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								player.sprint_speed = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 13;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									player.balance = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"balance", "player", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								player.balance = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 14;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									player.shot_power = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"shot_power", "player", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								player.shot_power = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 15;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									player.jumping = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"jumping", "player", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								player.jumping = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 16;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									player.stamina = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"stamina", "player", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								player.stamina = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 17;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									player.strength = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"strength", "player", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								player.strength = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 18;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									player.positioning = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"positioning", "player", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								player.positioning = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 19;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									player.penalties = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"penalties", "player", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								player.penalties = null;

							}

							columnIndexWithD_tFileInputDelimited_3 = 20;

							temp = fid_tFileInputDelimited_3.get(columnIndexWithD_tFileInputDelimited_3);
							if (temp.length() > 0) {

								try {

									player.sliding_tackle = ParserUtils.parseTo_Float(temp);

								} catch (java.lang.Exception ex_tFileInputDelimited_3) {
									globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE",
											ex_tFileInputDelimited_3.getMessage());
									rowstate_tFileInputDelimited_3.setException(new RuntimeException(String.format(
											"Couldn't parse value for column '%s' in '%s', value is '%s'. Details: %s",
											"sliding_tackle", "player", temp, ex_tFileInputDelimited_3),
											ex_tFileInputDelimited_3));
								}

							} else {

								player.sliding_tackle = null;

							}

							if (rowstate_tFileInputDelimited_3.getException() != null) {
								throw rowstate_tFileInputDelimited_3.getException();
							}

						} catch (java.lang.Exception e) {
							globalMap.put("tFileInputDelimited_3_ERROR_MESSAGE", e.getMessage());
							whetherReject_tFileInputDelimited_3 = true;

							System.err.println(e.getMessage());
							player = null;

						}

						/**
						 * [tFileInputDelimited_3 begin ] stop
						 */

						/**
						 * [tFileInputDelimited_3 main ] start
						 */

						currentComponent = "tFileInputDelimited_3";

						tos_count_tFileInputDelimited_3++;

						/**
						 * [tFileInputDelimited_3 main ] stop
						 */

						/**
						 * [tFileInputDelimited_3 process_data_begin ] start
						 */

						currentComponent = "tFileInputDelimited_3";

						/**
						 * [tFileInputDelimited_3 process_data_begin ] stop
						 */
// Start of branch "player"
						if (player != null) {

							/**
							 * [tMap_1 main ] start
							 */

							currentComponent = "tMap_1";

							if (execStat) {
								runStat.updateStatOnConnection(iterateId, 1, 1

										, "player"

								);
							}

							boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;

							// ###############################
							// # Input tables (lookups)
							boolean rejectedInnerJoin_tMap_1 = false;
							boolean mainRowRejected_tMap_1 = false;

							///////////////////////////////////////////////
							// Starting Lookup Table "all"
							///////////////////////////////////////////////

							boolean forceLoopall = false;

							allStruct allObjectFromLookup = null;

							if (!rejectedInnerJoin_tMap_1) { // G_TM_M_020

								hasCasePrimitiveKeyWithNull_tMap_1 = false;

								Object exprKeyValue_all__player_api_id = player.player_api_id;
								if (exprKeyValue_all__player_api_id == null) {
									hasCasePrimitiveKeyWithNull_tMap_1 = true;
								} else {
									allHashKey.player_api_id = (int) (Integer) exprKeyValue_all__player_api_id;
								}

								allHashKey.saison = player.saison;

								allHashKey.hashCodeDirty = true;

								if (!hasCasePrimitiveKeyWithNull_tMap_1) { // G_TM_M_091

									tHash_Lookup_all.lookup(allHashKey);

								} // G_TM_M_091

								if (hasCasePrimitiveKeyWithNull_tMap_1 || !tHash_Lookup_all.hasNext()) { // G_TM_M_090

									rejectedInnerJoin_tMap_1 = true;

								} // G_TM_M_090

							} // G_TM_M_020

							if (tHash_Lookup_all != null && tHash_Lookup_all.getCount(allHashKey) > 1) { // G 071

								// System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'all'
								// and it contains more one result from keys : all.player_api_id = '" +
								// allHashKey.player_api_id + "', all.saison = '" + allHashKey.saison + "'");
							} // G 071

							allStruct all = null;

							allStruct fromLookup_all = null;
							all = allDefault;

							if (tHash_Lookup_all != null && tHash_Lookup_all.hasNext()) { // G 099

								fromLookup_all = tHash_Lookup_all.next();

							} // G 099

							if (fromLookup_all != null) {
								all = fromLookup_all;
							}

							///////////////////////////////////////////////
							// Starting Lookup Table "team"
							///////////////////////////////////////////////

							boolean forceLoopteam = false;

							teamStruct teamObjectFromLookup = null;

							if (!rejectedInnerJoin_tMap_1) { // G_TM_M_020

								hasCasePrimitiveKeyWithNull_tMap_1 = false;

								teamHashKey.player_api_id = player.player_api_id;

								teamHashKey.saison = player.saison;

								teamHashKey.hashCodeDirty = true;

								tHash_Lookup_team.lookup(teamHashKey);

								if (!tHash_Lookup_team.hasNext()) { // G_TM_M_090

									rejectedInnerJoin_tMap_1 = true;

								} // G_TM_M_090

							} // G_TM_M_020

							if (tHash_Lookup_team != null && tHash_Lookup_team.getCount(teamHashKey) > 1) { // G 071

								// System.out.println("WARNING: UNIQUE MATCH is configured for the lookup 'team'
								// and it contains more one result from keys : team.player_api_id = '" +
								// teamHashKey.player_api_id + "', team.saison = '" + teamHashKey.saison + "'");
							} // G 071

							teamStruct team = null;

							teamStruct fromLookup_team = null;
							team = teamDefault;

							if (tHash_Lookup_team != null && tHash_Lookup_team.hasNext()) { // G 099

								fromLookup_team = tHash_Lookup_team.next();

							} // G 099

							if (fromLookup_team != null) {
								team = fromLookup_team;
							}

							// ###############################
							{ // start of Var scope

								// ###############################
								// # Vars tables

								Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
								// ###############################
								// # Output tables

								out1 = null;

								if (!rejectedInnerJoin_tMap_1) {

// # Output table : 'out1'
									out1_tmp.player_api_id = player.player_api_id;
									out1_tmp.player_name = player.player_name;
									out1_tmp.saison = player.saison;
									out1_tmp.overall_rating = player.overall_rating;
									out1_tmp.potential = player.potential;
									out1_tmp.finishing = player.finishing;
									out1_tmp.heading_accuracy = player.heading_accuracy;
									out1_tmp.short_passing = player.short_passing;
									out1_tmp.dribbling = player.dribbling;
									out1_tmp.sprint_speed = player.sprint_speed;
									out1_tmp.balance = player.balance;
									out1_tmp.shot_power = player.shot_power;
									out1_tmp.jumping = player.jumping;
									out1_tmp.stamina = player.stamina;
									out1_tmp.strength = player.strength;
									out1_tmp.positioning = player.positioning;
									out1_tmp.penalties = player.penalties;
									out1_tmp.sliding_tackle = player.sliding_tackle;
									out1_tmp.overall_rating_all = all.overall_rating;
									out1_tmp.potential_all = all.potential;
									out1_tmp.finishing_all = all.finishing;
									out1_tmp.heading_accuracy_all = all.heading_accuracy;
									out1_tmp.short_passing_all = all.short_passing;
									out1_tmp.dribbling_all = all.dribbling;
									out1_tmp.sprint_speed_all = all.sprint_speed;
									out1_tmp.balance_all = all.balance;
									out1_tmp.shot_power_all = all.shot_power;
									out1_tmp.jumping_all = all.jumping;
									out1_tmp.stamina_all = all.stamina;
									out1_tmp.strength_all = all.strength;
									out1_tmp.positioning_all = all.positioning;
									out1_tmp.penalties_all = all.penalties;
									out1_tmp.sliding_tackle_all = all.sliding_tackle;
									out1_tmp.overall_rating_team = team.overall_rating;
									out1_tmp.potential_team = team.potential;
									out1_tmp.finishing_team = team.finishing;
									out1_tmp.heading_accuracy_team = team.heading_accuracy;
									out1_tmp.short_passing_team = team.short_passing;
									out1_tmp.dribbling_team = team.dribbling;
									out1_tmp.sprint_speed_team = team.sprint_speed;
									out1_tmp.balance_team = team.balance;
									out1_tmp.shot_power_team = team.shot_power;
									out1_tmp.jumping_team = team.jumping;
									out1_tmp.stamina_team = team.stamina;
									out1_tmp.strength_team = team.strength;
									out1_tmp.positioning_team = team.positioning;
									out1_tmp.penalties_team = team.penalties;
									out1_tmp.sliding_tackle_team = team.sliding_tackle;
									out1 = out1_tmp;
								} // closing inner join bracket (2)
// ###############################

							} // end of Var scope

							rejectedInnerJoin_tMap_1 = false;

							tos_count_tMap_1++;

							/**
							 * [tMap_1 main ] stop
							 */

							/**
							 * [tMap_1 process_data_begin ] start
							 */

							currentComponent = "tMap_1";

							/**
							 * [tMap_1 process_data_begin ] stop
							 */
// Start of branch "out1"
							if (out1 != null) {

								/**
								 * [tFileOutputExcel_1 main ] start
								 */

								currentComponent = "tFileOutputExcel_1";

								if (execStat) {
									runStat.updateStatOnConnection(iterateId, 1, 1

											, "out1"

									);
								}

//modif start

								columnIndex_tFileOutputExcel_1 = 0;

								jxl.write.WritableCell cell_0_tFileOutputExcel_1 = new jxl.write.Number(
										columnIndex_tFileOutputExcel_1,
										startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
										out1.player_api_id);
//modif start					
								// If we keep the cell format from the existing cell in sheet

//modif ends							
								writableSheet_tFileOutputExcel_1.addCell(cell_0_tFileOutputExcel_1);
								int currentWith_0_tFileOutputExcel_1 = String
										.valueOf(((jxl.write.Number) cell_0_tFileOutputExcel_1).getValue()).trim()
										.length();
								currentWith_0_tFileOutputExcel_1 = currentWith_0_tFileOutputExcel_1 > 10 ? 10
										: currentWith_0_tFileOutputExcel_1;
								fitWidth_tFileOutputExcel_1[0] = fitWidth_tFileOutputExcel_1[0] > currentWith_0_tFileOutputExcel_1
										? fitWidth_tFileOutputExcel_1[0]
										: currentWith_0_tFileOutputExcel_1 + 2;

								if (out1.player_name != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 1;

									jxl.write.WritableCell cell_1_tFileOutputExcel_1 = new jxl.write.Label(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.player_name);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_1_tFileOutputExcel_1);
									int currentWith_1_tFileOutputExcel_1 = cell_1_tFileOutputExcel_1.getContents()
											.trim().length();
									fitWidth_tFileOutputExcel_1[1] = fitWidth_tFileOutputExcel_1[1] > currentWith_1_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[1]
											: currentWith_1_tFileOutputExcel_1 + 2;
								}

								if (out1.saison != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 2;

									jxl.write.WritableCell cell_2_tFileOutputExcel_1 = new jxl.write.Label(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.saison);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_2_tFileOutputExcel_1);
									int currentWith_2_tFileOutputExcel_1 = cell_2_tFileOutputExcel_1.getContents()
											.trim().length();
									fitWidth_tFileOutputExcel_1[2] = fitWidth_tFileOutputExcel_1[2] > currentWith_2_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[2]
											: currentWith_2_tFileOutputExcel_1 + 2;
								}

								if (out1.overall_rating != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 3;

									jxl.write.WritableCell cell_3_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.overall_rating);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_3_tFileOutputExcel_1);
									int currentWith_3_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_3_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_3_tFileOutputExcel_1 = currentWith_3_tFileOutputExcel_1 > 10 ? 10
											: currentWith_3_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[3] = fitWidth_tFileOutputExcel_1[3] > currentWith_3_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[3]
											: currentWith_3_tFileOutputExcel_1 + 2;
								}

								if (out1.potential != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 4;

									jxl.write.WritableCell cell_4_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.potential);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_4_tFileOutputExcel_1);
									int currentWith_4_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_4_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_4_tFileOutputExcel_1 = currentWith_4_tFileOutputExcel_1 > 10 ? 10
											: currentWith_4_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[4] = fitWidth_tFileOutputExcel_1[4] > currentWith_4_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[4]
											: currentWith_4_tFileOutputExcel_1 + 2;
								}

								if (out1.finishing != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 5;

									jxl.write.WritableCell cell_5_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.finishing);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_5_tFileOutputExcel_1);
									int currentWith_5_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_5_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_5_tFileOutputExcel_1 = currentWith_5_tFileOutputExcel_1 > 10 ? 10
											: currentWith_5_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[5] = fitWidth_tFileOutputExcel_1[5] > currentWith_5_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[5]
											: currentWith_5_tFileOutputExcel_1 + 2;
								}

								if (out1.heading_accuracy != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 6;

									jxl.write.WritableCell cell_6_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.heading_accuracy);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_6_tFileOutputExcel_1);
									int currentWith_6_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_6_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_6_tFileOutputExcel_1 = currentWith_6_tFileOutputExcel_1 > 10 ? 10
											: currentWith_6_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[6] = fitWidth_tFileOutputExcel_1[6] > currentWith_6_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[6]
											: currentWith_6_tFileOutputExcel_1 + 2;
								}

								if (out1.short_passing != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 7;

									jxl.write.WritableCell cell_7_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.short_passing);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_7_tFileOutputExcel_1);
									int currentWith_7_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_7_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_7_tFileOutputExcel_1 = currentWith_7_tFileOutputExcel_1 > 10 ? 10
											: currentWith_7_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[7] = fitWidth_tFileOutputExcel_1[7] > currentWith_7_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[7]
											: currentWith_7_tFileOutputExcel_1 + 2;
								}

								if (out1.dribbling != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 8;

									jxl.write.WritableCell cell_8_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.dribbling);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_8_tFileOutputExcel_1);
									int currentWith_8_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_8_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_8_tFileOutputExcel_1 = currentWith_8_tFileOutputExcel_1 > 10 ? 10
											: currentWith_8_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[8] = fitWidth_tFileOutputExcel_1[8] > currentWith_8_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[8]
											: currentWith_8_tFileOutputExcel_1 + 2;
								}

								if (out1.sprint_speed != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 9;

									jxl.write.WritableCell cell_9_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.sprint_speed);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_9_tFileOutputExcel_1);
									int currentWith_9_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_9_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_9_tFileOutputExcel_1 = currentWith_9_tFileOutputExcel_1 > 10 ? 10
											: currentWith_9_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[9] = fitWidth_tFileOutputExcel_1[9] > currentWith_9_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[9]
											: currentWith_9_tFileOutputExcel_1 + 2;
								}

								if (out1.balance != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 10;

									jxl.write.WritableCell cell_10_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.balance);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_10_tFileOutputExcel_1);
									int currentWith_10_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_10_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_10_tFileOutputExcel_1 = currentWith_10_tFileOutputExcel_1 > 10 ? 10
											: currentWith_10_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[10] = fitWidth_tFileOutputExcel_1[10] > currentWith_10_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[10]
											: currentWith_10_tFileOutputExcel_1 + 2;
								}

								if (out1.shot_power != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 11;

									jxl.write.WritableCell cell_11_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.shot_power);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_11_tFileOutputExcel_1);
									int currentWith_11_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_11_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_11_tFileOutputExcel_1 = currentWith_11_tFileOutputExcel_1 > 10 ? 10
											: currentWith_11_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[11] = fitWidth_tFileOutputExcel_1[11] > currentWith_11_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[11]
											: currentWith_11_tFileOutputExcel_1 + 2;
								}

								if (out1.jumping != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 12;

									jxl.write.WritableCell cell_12_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.jumping);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_12_tFileOutputExcel_1);
									int currentWith_12_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_12_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_12_tFileOutputExcel_1 = currentWith_12_tFileOutputExcel_1 > 10 ? 10
											: currentWith_12_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[12] = fitWidth_tFileOutputExcel_1[12] > currentWith_12_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[12]
											: currentWith_12_tFileOutputExcel_1 + 2;
								}

								if (out1.stamina != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 13;

									jxl.write.WritableCell cell_13_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.stamina);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_13_tFileOutputExcel_1);
									int currentWith_13_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_13_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_13_tFileOutputExcel_1 = currentWith_13_tFileOutputExcel_1 > 10 ? 10
											: currentWith_13_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[13] = fitWidth_tFileOutputExcel_1[13] > currentWith_13_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[13]
											: currentWith_13_tFileOutputExcel_1 + 2;
								}

								if (out1.strength != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 14;

									jxl.write.WritableCell cell_14_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.strength);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_14_tFileOutputExcel_1);
									int currentWith_14_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_14_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_14_tFileOutputExcel_1 = currentWith_14_tFileOutputExcel_1 > 10 ? 10
											: currentWith_14_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[14] = fitWidth_tFileOutputExcel_1[14] > currentWith_14_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[14]
											: currentWith_14_tFileOutputExcel_1 + 2;
								}

								if (out1.positioning != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 15;

									jxl.write.WritableCell cell_15_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.positioning);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_15_tFileOutputExcel_1);
									int currentWith_15_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_15_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_15_tFileOutputExcel_1 = currentWith_15_tFileOutputExcel_1 > 10 ? 10
											: currentWith_15_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[15] = fitWidth_tFileOutputExcel_1[15] > currentWith_15_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[15]
											: currentWith_15_tFileOutputExcel_1 + 2;
								}

								if (out1.penalties != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 16;

									jxl.write.WritableCell cell_16_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.penalties);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_16_tFileOutputExcel_1);
									int currentWith_16_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_16_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_16_tFileOutputExcel_1 = currentWith_16_tFileOutputExcel_1 > 10 ? 10
											: currentWith_16_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[16] = fitWidth_tFileOutputExcel_1[16] > currentWith_16_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[16]
											: currentWith_16_tFileOutputExcel_1 + 2;
								}

								if (out1.sliding_tackle != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 17;

									jxl.write.WritableCell cell_17_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.sliding_tackle);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_17_tFileOutputExcel_1);
									int currentWith_17_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_17_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_17_tFileOutputExcel_1 = currentWith_17_tFileOutputExcel_1 > 10 ? 10
											: currentWith_17_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[17] = fitWidth_tFileOutputExcel_1[17] > currentWith_17_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[17]
											: currentWith_17_tFileOutputExcel_1 + 2;
								}

								if (out1.overall_rating_all != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 18;

									jxl.write.WritableCell cell_18_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.overall_rating_all);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_18_tFileOutputExcel_1);
									int currentWith_18_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_18_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_18_tFileOutputExcel_1 = currentWith_18_tFileOutputExcel_1 > 10 ? 10
											: currentWith_18_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[18] = fitWidth_tFileOutputExcel_1[18] > currentWith_18_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[18]
											: currentWith_18_tFileOutputExcel_1 + 2;
								}

								if (out1.potential_all != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 19;

									jxl.write.WritableCell cell_19_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.potential_all);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_19_tFileOutputExcel_1);
									int currentWith_19_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_19_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_19_tFileOutputExcel_1 = currentWith_19_tFileOutputExcel_1 > 10 ? 10
											: currentWith_19_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[19] = fitWidth_tFileOutputExcel_1[19] > currentWith_19_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[19]
											: currentWith_19_tFileOutputExcel_1 + 2;
								}

								if (out1.finishing_all != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 20;

									jxl.write.WritableCell cell_20_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.finishing_all);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_20_tFileOutputExcel_1);
									int currentWith_20_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_20_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_20_tFileOutputExcel_1 = currentWith_20_tFileOutputExcel_1 > 10 ? 10
											: currentWith_20_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[20] = fitWidth_tFileOutputExcel_1[20] > currentWith_20_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[20]
											: currentWith_20_tFileOutputExcel_1 + 2;
								}

								if (out1.heading_accuracy_all != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 21;

									jxl.write.WritableCell cell_21_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.heading_accuracy_all);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_21_tFileOutputExcel_1);
									int currentWith_21_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_21_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_21_tFileOutputExcel_1 = currentWith_21_tFileOutputExcel_1 > 10 ? 10
											: currentWith_21_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[21] = fitWidth_tFileOutputExcel_1[21] > currentWith_21_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[21]
											: currentWith_21_tFileOutputExcel_1 + 2;
								}

								if (out1.short_passing_all != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 22;

									jxl.write.WritableCell cell_22_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.short_passing_all);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_22_tFileOutputExcel_1);
									int currentWith_22_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_22_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_22_tFileOutputExcel_1 = currentWith_22_tFileOutputExcel_1 > 10 ? 10
											: currentWith_22_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[22] = fitWidth_tFileOutputExcel_1[22] > currentWith_22_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[22]
											: currentWith_22_tFileOutputExcel_1 + 2;
								}

								if (out1.dribbling_all != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 23;

									jxl.write.WritableCell cell_23_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.dribbling_all);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_23_tFileOutputExcel_1);
									int currentWith_23_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_23_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_23_tFileOutputExcel_1 = currentWith_23_tFileOutputExcel_1 > 10 ? 10
											: currentWith_23_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[23] = fitWidth_tFileOutputExcel_1[23] > currentWith_23_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[23]
											: currentWith_23_tFileOutputExcel_1 + 2;
								}

								if (out1.sprint_speed_all != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 24;

									jxl.write.WritableCell cell_24_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.sprint_speed_all);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_24_tFileOutputExcel_1);
									int currentWith_24_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_24_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_24_tFileOutputExcel_1 = currentWith_24_tFileOutputExcel_1 > 10 ? 10
											: currentWith_24_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[24] = fitWidth_tFileOutputExcel_1[24] > currentWith_24_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[24]
											: currentWith_24_tFileOutputExcel_1 + 2;
								}

								if (out1.balance_all != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 25;

									jxl.write.WritableCell cell_25_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.balance_all);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_25_tFileOutputExcel_1);
									int currentWith_25_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_25_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_25_tFileOutputExcel_1 = currentWith_25_tFileOutputExcel_1 > 10 ? 10
											: currentWith_25_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[25] = fitWidth_tFileOutputExcel_1[25] > currentWith_25_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[25]
											: currentWith_25_tFileOutputExcel_1 + 2;
								}

								if (out1.shot_power_all != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 26;

									jxl.write.WritableCell cell_26_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.shot_power_all);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_26_tFileOutputExcel_1);
									int currentWith_26_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_26_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_26_tFileOutputExcel_1 = currentWith_26_tFileOutputExcel_1 > 10 ? 10
											: currentWith_26_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[26] = fitWidth_tFileOutputExcel_1[26] > currentWith_26_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[26]
											: currentWith_26_tFileOutputExcel_1 + 2;
								}

								if (out1.jumping_all != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 27;

									jxl.write.WritableCell cell_27_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.jumping_all);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_27_tFileOutputExcel_1);
									int currentWith_27_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_27_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_27_tFileOutputExcel_1 = currentWith_27_tFileOutputExcel_1 > 10 ? 10
											: currentWith_27_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[27] = fitWidth_tFileOutputExcel_1[27] > currentWith_27_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[27]
											: currentWith_27_tFileOutputExcel_1 + 2;
								}

								if (out1.stamina_all != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 28;

									jxl.write.WritableCell cell_28_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.stamina_all);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_28_tFileOutputExcel_1);
									int currentWith_28_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_28_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_28_tFileOutputExcel_1 = currentWith_28_tFileOutputExcel_1 > 10 ? 10
											: currentWith_28_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[28] = fitWidth_tFileOutputExcel_1[28] > currentWith_28_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[28]
											: currentWith_28_tFileOutputExcel_1 + 2;
								}

								if (out1.strength_all != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 29;

									jxl.write.WritableCell cell_29_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.strength_all);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_29_tFileOutputExcel_1);
									int currentWith_29_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_29_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_29_tFileOutputExcel_1 = currentWith_29_tFileOutputExcel_1 > 10 ? 10
											: currentWith_29_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[29] = fitWidth_tFileOutputExcel_1[29] > currentWith_29_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[29]
											: currentWith_29_tFileOutputExcel_1 + 2;
								}

								if (out1.positioning_all != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 30;

									jxl.write.WritableCell cell_30_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.positioning_all);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_30_tFileOutputExcel_1);
									int currentWith_30_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_30_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_30_tFileOutputExcel_1 = currentWith_30_tFileOutputExcel_1 > 10 ? 10
											: currentWith_30_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[30] = fitWidth_tFileOutputExcel_1[30] > currentWith_30_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[30]
											: currentWith_30_tFileOutputExcel_1 + 2;
								}

								if (out1.penalties_all != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 31;

									jxl.write.WritableCell cell_31_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.penalties_all);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_31_tFileOutputExcel_1);
									int currentWith_31_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_31_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_31_tFileOutputExcel_1 = currentWith_31_tFileOutputExcel_1 > 10 ? 10
											: currentWith_31_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[31] = fitWidth_tFileOutputExcel_1[31] > currentWith_31_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[31]
											: currentWith_31_tFileOutputExcel_1 + 2;
								}

								if (out1.sliding_tackle_all != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 32;

									jxl.write.WritableCell cell_32_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.sliding_tackle_all);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_32_tFileOutputExcel_1);
									int currentWith_32_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_32_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_32_tFileOutputExcel_1 = currentWith_32_tFileOutputExcel_1 > 10 ? 10
											: currentWith_32_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[32] = fitWidth_tFileOutputExcel_1[32] > currentWith_32_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[32]
											: currentWith_32_tFileOutputExcel_1 + 2;
								}

								if (out1.overall_rating_team != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 33;

									jxl.write.WritableCell cell_33_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.overall_rating_team);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_33_tFileOutputExcel_1);
									int currentWith_33_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_33_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_33_tFileOutputExcel_1 = currentWith_33_tFileOutputExcel_1 > 10 ? 10
											: currentWith_33_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[33] = fitWidth_tFileOutputExcel_1[33] > currentWith_33_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[33]
											: currentWith_33_tFileOutputExcel_1 + 2;
								}

								if (out1.potential_team != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 34;

									jxl.write.WritableCell cell_34_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.potential_team);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_34_tFileOutputExcel_1);
									int currentWith_34_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_34_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_34_tFileOutputExcel_1 = currentWith_34_tFileOutputExcel_1 > 10 ? 10
											: currentWith_34_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[34] = fitWidth_tFileOutputExcel_1[34] > currentWith_34_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[34]
											: currentWith_34_tFileOutputExcel_1 + 2;
								}

								if (out1.finishing_team != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 35;

									jxl.write.WritableCell cell_35_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.finishing_team);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_35_tFileOutputExcel_1);
									int currentWith_35_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_35_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_35_tFileOutputExcel_1 = currentWith_35_tFileOutputExcel_1 > 10 ? 10
											: currentWith_35_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[35] = fitWidth_tFileOutputExcel_1[35] > currentWith_35_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[35]
											: currentWith_35_tFileOutputExcel_1 + 2;
								}

								if (out1.heading_accuracy_team != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 36;

									jxl.write.WritableCell cell_36_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.heading_accuracy_team);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_36_tFileOutputExcel_1);
									int currentWith_36_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_36_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_36_tFileOutputExcel_1 = currentWith_36_tFileOutputExcel_1 > 10 ? 10
											: currentWith_36_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[36] = fitWidth_tFileOutputExcel_1[36] > currentWith_36_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[36]
											: currentWith_36_tFileOutputExcel_1 + 2;
								}

								if (out1.short_passing_team != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 37;

									jxl.write.WritableCell cell_37_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.short_passing_team);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_37_tFileOutputExcel_1);
									int currentWith_37_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_37_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_37_tFileOutputExcel_1 = currentWith_37_tFileOutputExcel_1 > 10 ? 10
											: currentWith_37_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[37] = fitWidth_tFileOutputExcel_1[37] > currentWith_37_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[37]
											: currentWith_37_tFileOutputExcel_1 + 2;
								}

								if (out1.dribbling_team != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 38;

									jxl.write.WritableCell cell_38_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.dribbling_team);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_38_tFileOutputExcel_1);
									int currentWith_38_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_38_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_38_tFileOutputExcel_1 = currentWith_38_tFileOutputExcel_1 > 10 ? 10
											: currentWith_38_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[38] = fitWidth_tFileOutputExcel_1[38] > currentWith_38_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[38]
											: currentWith_38_tFileOutputExcel_1 + 2;
								}

								if (out1.sprint_speed_team != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 39;

									jxl.write.WritableCell cell_39_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.sprint_speed_team);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_39_tFileOutputExcel_1);
									int currentWith_39_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_39_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_39_tFileOutputExcel_1 = currentWith_39_tFileOutputExcel_1 > 10 ? 10
											: currentWith_39_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[39] = fitWidth_tFileOutputExcel_1[39] > currentWith_39_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[39]
											: currentWith_39_tFileOutputExcel_1 + 2;
								}

								if (out1.balance_team != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 40;

									jxl.write.WritableCell cell_40_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.balance_team);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_40_tFileOutputExcel_1);
									int currentWith_40_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_40_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_40_tFileOutputExcel_1 = currentWith_40_tFileOutputExcel_1 > 10 ? 10
											: currentWith_40_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[40] = fitWidth_tFileOutputExcel_1[40] > currentWith_40_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[40]
											: currentWith_40_tFileOutputExcel_1 + 2;
								}

								if (out1.shot_power_team != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 41;

									jxl.write.WritableCell cell_41_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.shot_power_team);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_41_tFileOutputExcel_1);
									int currentWith_41_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_41_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_41_tFileOutputExcel_1 = currentWith_41_tFileOutputExcel_1 > 10 ? 10
											: currentWith_41_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[41] = fitWidth_tFileOutputExcel_1[41] > currentWith_41_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[41]
											: currentWith_41_tFileOutputExcel_1 + 2;
								}

								if (out1.jumping_team != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 42;

									jxl.write.WritableCell cell_42_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.jumping_team);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_42_tFileOutputExcel_1);
									int currentWith_42_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_42_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_42_tFileOutputExcel_1 = currentWith_42_tFileOutputExcel_1 > 10 ? 10
											: currentWith_42_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[42] = fitWidth_tFileOutputExcel_1[42] > currentWith_42_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[42]
											: currentWith_42_tFileOutputExcel_1 + 2;
								}

								if (out1.stamina_team != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 43;

									jxl.write.WritableCell cell_43_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.stamina_team);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_43_tFileOutputExcel_1);
									int currentWith_43_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_43_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_43_tFileOutputExcel_1 = currentWith_43_tFileOutputExcel_1 > 10 ? 10
											: currentWith_43_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[43] = fitWidth_tFileOutputExcel_1[43] > currentWith_43_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[43]
											: currentWith_43_tFileOutputExcel_1 + 2;
								}

								if (out1.strength_team != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 44;

									jxl.write.WritableCell cell_44_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.strength_team);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_44_tFileOutputExcel_1);
									int currentWith_44_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_44_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_44_tFileOutputExcel_1 = currentWith_44_tFileOutputExcel_1 > 10 ? 10
											: currentWith_44_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[44] = fitWidth_tFileOutputExcel_1[44] > currentWith_44_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[44]
											: currentWith_44_tFileOutputExcel_1 + 2;
								}

								if (out1.positioning_team != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 45;

									jxl.write.WritableCell cell_45_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.positioning_team);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_45_tFileOutputExcel_1);
									int currentWith_45_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_45_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_45_tFileOutputExcel_1 = currentWith_45_tFileOutputExcel_1 > 10 ? 10
											: currentWith_45_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[45] = fitWidth_tFileOutputExcel_1[45] > currentWith_45_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[45]
											: currentWith_45_tFileOutputExcel_1 + 2;
								}

								if (out1.penalties_team != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 46;

									jxl.write.WritableCell cell_46_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.penalties_team);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_46_tFileOutputExcel_1);
									int currentWith_46_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_46_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_46_tFileOutputExcel_1 = currentWith_46_tFileOutputExcel_1 > 10 ? 10
											: currentWith_46_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[46] = fitWidth_tFileOutputExcel_1[46] > currentWith_46_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[46]
											: currentWith_46_tFileOutputExcel_1 + 2;
								}

								if (out1.sliding_tackle_team != null) {

//modif start

									columnIndex_tFileOutputExcel_1 = 47;

									jxl.write.WritableCell cell_47_tFileOutputExcel_1 = new jxl.write.Number(
											columnIndex_tFileOutputExcel_1,
											startRowNum_tFileOutputExcel_1 + nb_line_tFileOutputExcel_1,

//modif end
											out1.sliding_tackle_team);
//modif start					
									// If we keep the cell format from the existing cell in sheet

//modif ends							
									writableSheet_tFileOutputExcel_1.addCell(cell_47_tFileOutputExcel_1);
									int currentWith_47_tFileOutputExcel_1 = String
											.valueOf(((jxl.write.Number) cell_47_tFileOutputExcel_1).getValue()).trim()
											.length();
									currentWith_47_tFileOutputExcel_1 = currentWith_47_tFileOutputExcel_1 > 10 ? 10
											: currentWith_47_tFileOutputExcel_1;
									fitWidth_tFileOutputExcel_1[47] = fitWidth_tFileOutputExcel_1[47] > currentWith_47_tFileOutputExcel_1
											? fitWidth_tFileOutputExcel_1[47]
											: currentWith_47_tFileOutputExcel_1 + 2;
								}

								nb_line_tFileOutputExcel_1++;

								tos_count_tFileOutputExcel_1++;

								/**
								 * [tFileOutputExcel_1 main ] stop
								 */

								/**
								 * [tFileOutputExcel_1 process_data_begin ] start
								 */

								currentComponent = "tFileOutputExcel_1";

								/**
								 * [tFileOutputExcel_1 process_data_begin ] stop
								 */

								/**
								 * [tFileOutputExcel_1 process_data_end ] start
								 */

								currentComponent = "tFileOutputExcel_1";

								/**
								 * [tFileOutputExcel_1 process_data_end ] stop
								 */

							} // End of branch "out1"

							/**
							 * [tMap_1 process_data_end ] start
							 */

							currentComponent = "tMap_1";

							/**
							 * [tMap_1 process_data_end ] stop
							 */

						} // End of branch "player"

						/**
						 * [tFileInputDelimited_3 process_data_end ] start
						 */

						currentComponent = "tFileInputDelimited_3";

						/**
						 * [tFileInputDelimited_3 process_data_end ] stop
						 */

						/**
						 * [tFileInputDelimited_3 end ] start
						 */

						currentComponent = "tFileInputDelimited_3";

					}
				} finally {
					if (!((Object) ("C:/Users/Thinkpad/Desktop/PLAYER.csv") instanceof java.io.InputStream)) {
						if (fid_tFileInputDelimited_3 != null) {
							fid_tFileInputDelimited_3.close();
						}
					}
					if (fid_tFileInputDelimited_3 != null) {
						globalMap.put("tFileInputDelimited_3_NB_LINE", fid_tFileInputDelimited_3.getRowNumber());

					}
				}

				ok_Hash.put("tFileInputDelimited_3", true);
				end_Hash.put("tFileInputDelimited_3", System.currentTimeMillis());

				/**
				 * [tFileInputDelimited_3 end ] stop
				 */

				/**
				 * [tMap_1 end ] start
				 */

				currentComponent = "tMap_1";

// ###############################
// # Lookup hashes releasing
				if (tHash_Lookup_all != null) {
					tHash_Lookup_all.endGet();
				}
				globalMap.remove("tHash_Lookup_all");

				if (tHash_Lookup_team != null) {
					tHash_Lookup_team.endGet();
				}
				globalMap.remove("tHash_Lookup_team");

// ###############################      

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "player");
				}

				ok_Hash.put("tMap_1", true);
				end_Hash.put("tMap_1", System.currentTimeMillis());

				/**
				 * [tMap_1 end ] stop
				 */

				/**
				 * [tFileOutputExcel_1 end ] start
				 */

				currentComponent = "tFileOutputExcel_1";

				writeableWorkbook_tFileOutputExcel_1.write();
				writeableWorkbook_tFileOutputExcel_1.close();
				if (headerIsInserted_tFileOutputExcel_1 && nb_line_tFileOutputExcel_1 > 0) {
					nb_line_tFileOutputExcel_1 = nb_line_tFileOutputExcel_1 - 1;
				}
				globalMap.put("tFileOutputExcel_1_NB_LINE", nb_line_tFileOutputExcel_1);

				if (execStat) {
					runStat.updateStat(resourceMap, iterateId, 2, 0, "out1");
				}

				ok_Hash.put("tFileOutputExcel_1", true);
				end_Hash.put("tFileOutputExcel_1", System.currentTimeMillis());

				/**
				 * [tFileOutputExcel_1 end ] stop
				 */

			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			// free memory for "tMap_1"
			globalMap.remove("tHash_Lookup_all");

			// free memory for "tMap_1"
			globalMap.remove("tHash_Lookup_team");

			try {

				/**
				 * [tFileInputDelimited_3 finally ] start
				 */

				currentComponent = "tFileInputDelimited_3";

				/**
				 * [tFileInputDelimited_3 finally ] stop
				 */

				/**
				 * [tMap_1 finally ] start
				 */

				currentComponent = "tMap_1";

				/**
				 * [tMap_1 finally ] stop
				 */

				/**
				 * [tFileOutputExcel_1 finally ] start
				 */

				currentComponent = "tFileOutputExcel_1";

				/**
				 * [tFileOutputExcel_1 finally ] stop
				 */

			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileInputDelimited_3_SUBPROCESS_STATE", 1);
	}

	public void tFileOutputDelimited_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
		globalMap.put("tFileOutputDelimited_1_SUBPROCESS_STATE", 0);

		final boolean execStat = this.execStat;

		String iterateId = "";

		String currentComponent = "";
		java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

		try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { // start the resume
				globalResumeTicket = true;

				/**
				 * [tFileOutputDelimited_1 begin ] start
				 */

				ok_Hash.put("tFileOutputDelimited_1", false);
				start_Hash.put("tFileOutputDelimited_1", System.currentTimeMillis());

				currentComponent = "tFileOutputDelimited_1";

				int tos_count_tFileOutputDelimited_1 = 0;

				String fileName_tFileOutputDelimited_1 = "";
				fileName_tFileOutputDelimited_1 = (new java.io.File(
						"C:/Users/Thinkpad/Desktop/compare_player_all_team.csv")).getAbsolutePath().replace("\\", "/");
				String fullName_tFileOutputDelimited_1 = null;
				String extension_tFileOutputDelimited_1 = null;
				String directory_tFileOutputDelimited_1 = null;
				if ((fileName_tFileOutputDelimited_1.indexOf("/") != -1)) {
					if (fileName_tFileOutputDelimited_1.lastIndexOf(".") < fileName_tFileOutputDelimited_1
							.lastIndexOf("/")) {
						fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1;
						extension_tFileOutputDelimited_1 = "";
					} else {
						fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0,
								fileName_tFileOutputDelimited_1.lastIndexOf("."));
						extension_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1
								.substring(fileName_tFileOutputDelimited_1.lastIndexOf("."));
					}
					directory_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0,
							fileName_tFileOutputDelimited_1.lastIndexOf("/"));
				} else {
					if (fileName_tFileOutputDelimited_1.lastIndexOf(".") != -1) {
						fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1.substring(0,
								fileName_tFileOutputDelimited_1.lastIndexOf("."));
						extension_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1
								.substring(fileName_tFileOutputDelimited_1.lastIndexOf("."));
					} else {
						fullName_tFileOutputDelimited_1 = fileName_tFileOutputDelimited_1;
						extension_tFileOutputDelimited_1 = "";
					}
					directory_tFileOutputDelimited_1 = "";
				}
				boolean isFileGenerated_tFileOutputDelimited_1 = true;
				java.io.File filetFileOutputDelimited_1 = new java.io.File(fileName_tFileOutputDelimited_1);
				globalMap.put("tFileOutputDelimited_1_FILE_NAME", fileName_tFileOutputDelimited_1);
				int nb_line_tFileOutputDelimited_1 = 0;
				int splitedFileNo_tFileOutputDelimited_1 = 0;
				int currentRow_tFileOutputDelimited_1 = 0;

				final String OUT_DELIM_tFileOutputDelimited_1 = /** Start field tFileOutputDelimited_1:FIELDSEPARATOR */
						";"/** End field tFileOutputDelimited_1:FIELDSEPARATOR */
				;

				final String OUT_DELIM_ROWSEP_tFileOutputDelimited_1 = /**
																		 * Start field
																		 * tFileOutputDelimited_1:ROWSEPARATOR
																		 */
						"\n"/** End field tFileOutputDelimited_1:ROWSEPARATOR */
				;

				// create directory only if not exists
				if (directory_tFileOutputDelimited_1 != null && directory_tFileOutputDelimited_1.trim().length() != 0) {
					java.io.File dir_tFileOutputDelimited_1 = new java.io.File(directory_tFileOutputDelimited_1);
					if (!dir_tFileOutputDelimited_1.exists()) {
						dir_tFileOutputDelimited_1.mkdirs();
					}
				}

				// routines.system.Row
				java.io.Writer outtFileOutputDelimited_1 = null;

				java.io.File fileToDelete_tFileOutputDelimited_1 = new java.io.File(fileName_tFileOutputDelimited_1);
				if (fileToDelete_tFileOutputDelimited_1.exists()) {
					fileToDelete_tFileOutputDelimited_1.delete();
				}
				outtFileOutputDelimited_1 = new java.io.BufferedWriter(new java.io.OutputStreamWriter(
						new java.io.FileOutputStream(fileName_tFileOutputDelimited_1, false), "ISO-8859-15"));
				if (filetFileOutputDelimited_1.length() == 0) {
					outtFileOutputDelimited_1.write("player_api_id");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("player_name");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("saison");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("overall_rating");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("potential");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("finishing");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("heading_accuracy");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("short_passing");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("dribbling");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("sprint_speed");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("balance");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("shot_power");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("jumping");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("stamina");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("strength");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("positioning");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("penalties");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("sliding_tackle");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("overall_rating_all");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("potential_all");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("finishing_all");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("heading_accuracy_all");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("short_passing_all");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("dribbling_all");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("sprint_speed_all");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("balance_all");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("shot_power_all");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("jumping_all");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("stamina_all");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("strength_all");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("positioning_all");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("penalties_all");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("sliding_tackle_all");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("overall_rating_team");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("potential_team");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("finishing_team");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("heading_accuracy_team");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("short_passing_team");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("dribbling_team");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("sprint_speed_team");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("balance_team");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("shot_power_team");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("jumping_team");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("stamina_team");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("strength_team");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("positioning_team");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("penalties_team");
					outtFileOutputDelimited_1.write(OUT_DELIM_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.write("sliding_tackle_team");
					outtFileOutputDelimited_1.write(OUT_DELIM_ROWSEP_tFileOutputDelimited_1);
					outtFileOutputDelimited_1.flush();
				}

				resourceMap.put("out_tFileOutputDelimited_1", outtFileOutputDelimited_1);
				resourceMap.put("nb_line_tFileOutputDelimited_1", nb_line_tFileOutputDelimited_1);

				/**
				 * [tFileOutputDelimited_1 begin ] stop
				 */

				/**
				 * [tFileOutputDelimited_1 main ] start
				 */

				currentComponent = "tFileOutputDelimited_1";

				tos_count_tFileOutputDelimited_1++;

				/**
				 * [tFileOutputDelimited_1 main ] stop
				 */

				/**
				 * [tFileOutputDelimited_1 process_data_begin ] start
				 */

				currentComponent = "tFileOutputDelimited_1";

				/**
				 * [tFileOutputDelimited_1 process_data_begin ] stop
				 */

				/**
				 * [tFileOutputDelimited_1 process_data_end ] start
				 */

				currentComponent = "tFileOutputDelimited_1";

				/**
				 * [tFileOutputDelimited_1 process_data_end ] stop
				 */

				/**
				 * [tFileOutputDelimited_1 end ] start
				 */

				currentComponent = "tFileOutputDelimited_1";

				if (outtFileOutputDelimited_1 != null) {
					outtFileOutputDelimited_1.flush();
					outtFileOutputDelimited_1.close();
				}

				globalMap.put("tFileOutputDelimited_1_NB_LINE", nb_line_tFileOutputDelimited_1);
				globalMap.put("tFileOutputDelimited_1_FILE_NAME", fileName_tFileOutputDelimited_1);

				resourceMap.put("finish_tFileOutputDelimited_1", true);

				ok_Hash.put("tFileOutputDelimited_1", true);
				end_Hash.put("tFileOutputDelimited_1", System.currentTimeMillis());

				/**
				 * [tFileOutputDelimited_1 end ] stop
				 */
			} // end the resume

		} catch (java.lang.Exception e) {

			TalendException te = new TalendException(e, currentComponent, globalMap);

			throw te;
		} catch (java.lang.Error error) {

			runStat.stopThreadStat();

			throw error;
		} finally {

			try {

				/**
				 * [tFileOutputDelimited_1 finally ] start
				 */

				currentComponent = "tFileOutputDelimited_1";

				if (resourceMap.get("finish_tFileOutputDelimited_1") == null) {

					java.io.Writer outtFileOutputDelimited_1 = (java.io.Writer) resourceMap
							.get("out_tFileOutputDelimited_1");
					if (outtFileOutputDelimited_1 != null) {
						outtFileOutputDelimited_1.flush();
						outtFileOutputDelimited_1.close();
					}

				}

				/**
				 * [tFileOutputDelimited_1 finally ] stop
				 */
			} catch (java.lang.Exception e) {
				// ignore
			} catch (java.lang.Error error) {
				// ignore
			}
			resourceMap = null;
		}

		globalMap.put("tFileOutputDelimited_1_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	// portStats is null, it means don't execute the statistics
	public Integer portStats = null;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public boolean isDefaultContext = true;
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public String fatherNode = null;
	public long startTime = 0;
	public boolean isChildJob = false;
	public String log4jLevel = "";

	private boolean enableLogStash;

	private boolean execStat = true;

	private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
		protected java.util.Map<String, String> initialValue() {
			java.util.Map<String, String> threadRunResultMap = new java.util.HashMap<String, String>();
			threadRunResultMap.put("errorCode", null);
			threadRunResultMap.put("status", "");
			return threadRunResultMap;
		};
	};

	protected PropertiesWithType context_param = new PropertiesWithType();
	public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

	public String status = "";

	public static void main(String[] args) {
		final fusionnage_player_comparison fusionnage_player_comparisonClass = new fusionnage_player_comparison();

		int exitCode = fusionnage_player_comparisonClass.runJobInTOS(args);

		System.exit(exitCode);
	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

		return bufferValue;
	}

	public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;

		return hastBufferOutput;
	}

	public int runJobInTOS(String[] args) {
		// reset status
		status = "";

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}
		enableLogStash = "true".equalsIgnoreCase(System.getProperty("audit.enabled"));

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		if (rootPid == null) {
			rootPid = pid;
		}
		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}

		if (portStats != null) {
			// portStats = -1; //for testing
			if (portStats < 0 || portStats > 65535) {
				// issue:10869, the portStats is invalid, so this client socket can't open
				System.err.println("The statistics socket port " + portStats + " is invalid.");
				execStat = false;
			}
		} else {
			execStat = false;
		}
		boolean inOSGi = routines.system.BundleUtils.inOSGi();

		if (inOSGi) {
			java.util.Dictionary<String, Object> jobProperties = routines.system.BundleUtils.getJobProperties(jobName);

			if (jobProperties != null && jobProperties.get("context") != null) {
				contextStr = (String) jobProperties.get("context");
			}
		}

		try {
			// call job/subjob with an existing context, like: --context=production. if
			// without this parameter, there will use the default context instead.
			java.io.InputStream inContext = fusionnage_player_comparison.class.getClassLoader().getResourceAsStream(
					"edd_projet/fusionnage_player_comparison_0_1/contexts/" + contextStr + ".properties");
			if (inContext == null) {
				inContext = fusionnage_player_comparison.class.getClassLoader()
						.getResourceAsStream("config/contexts/" + contextStr + ".properties");
			}
			if (inContext != null) {
				try {
					// defaultProps is in order to keep the original context value
					if (context != null && context.isEmpty()) {
						defaultProps.load(inContext);
						context = new ContextProperties(defaultProps);
					}
				} finally {
					inContext.close();
				}
			} else if (!isDefaultContext) {
				// print info and job continue to run, for case: context_param is not empty.
				System.err.println("Could not find the context " + contextStr);
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
				// set types for params from parentJobs
				for (Object key : context_param.keySet()) {
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
			}
			class ContextProcessing {
				private void processContext_0() {
				}

				public void processAllContext() {
					processContext_0();
				}
			}

			new ContextProcessing().processAllContext();
		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		// get context value from parent directly
		if (parentContextMap != null && !parentContextMap.isEmpty()) {
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "",
				"", "", "", "", resumeUtil.convertToJsonText(context, parametersToEncrypt));

		if (execStat) {
			try {
				runStat.openSocket(!isChildJob);
				runStat.setAllPID(rootPid, fatherPid, pid, jobName);
				runStat.startThreadStat(clientHost, portStats);
				runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
			} catch (java.io.IOException ioException) {
				ioException.printStackTrace();
			}
		}

		java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
		globalMap.put("concurrentHashMap", concurrentHashMap);

		long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();

		this.globalResumeTicket = true;// to run tPreJob

		this.globalResumeTicket = false;// to run others jobs

		try {
			errorCode = null;
			tFileInputDelimited_3Process(globalMap);
			if (!"failure".equals(status)) {
				status = "end";
			}
		} catch (TalendException e_tFileInputDelimited_3) {
			globalMap.put("tFileInputDelimited_3_SUBPROCESS_STATE", -1);

			e_tFileInputDelimited_3.printStackTrace();

		}

		this.globalResumeTicket = true;// to run tPostJob

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
		if (false) {
			System.out.println((endUsedMemory - startUsedMemory)
					+ " bytes memory increase when running : fusionnage_player_comparison");
		}

		if (execStat) {
			runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
			runStat.stopThreadStat();
		}
		int returnCode = 0;

		if (errorCode == null) {
			returnCode = status != null && status.equals("failure") ? 1 : 0;
		} else {
			returnCode = errorCode.intValue();
		}
		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "",
				"" + returnCode, "", "", "");

		return returnCode;

	}

	// only for OSGi env
	public void destroy() {

	}

	private java.util.Map<String, Object> getSharedConnections4REST() {
		java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();

		return connections;
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			String portStatsStr = arg.substring(12);
			if (portStatsStr != null && !portStatsStr.equals("null")) {
				portStats = Integer.parseInt(portStatsStr);
			}
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
			isDefaultContext = false;
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--father_node=")) {
			fatherNode = arg.substring(14);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_type")) {
			String keyValue = arg.substring(15);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.setContextType(keyValue.substring(0, index),
							replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1));
				}

			}

		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				if (fatherPid == null) {
					context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
				} else { // the subjob won't escape the especial chars
					context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1));
				}
			}
		} else if (arg.startsWith("--log4jLevel=")) {
			log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--audit.enabled") && arg.contains("=")) {// for trunjob call
			final int equal = arg.indexOf('=');
			final String key = arg.substring("--".length(), equal);
			System.setProperty(key, arg.substring(equal + 1));
		}
	}

	private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

	private final String[][] escapeChars = { { "\\\\", "\\" }, { "\\n", "\n" }, { "\\'", "\'" }, { "\\r", "\r" },
			{ "\\f", "\f" }, { "\\b", "\b" }, { "\\t", "\t" } };

	private String replaceEscapeChars(String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0], currIndex);
				if (index >= 0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0],
							strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the
			// result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 361480 characters generated by Talend Open Studio for Data Integration on the
 * 19 janvier 2024, 14:31:15 CET
 ************************************************************************************************/